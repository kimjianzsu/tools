package org.eclipse.wst.xsd.ui.internal.adt.design.editparts;

public interface IConnectionContainer
{
  public void refreshConnections();
}
