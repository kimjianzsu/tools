/*******************************************************************************
 * Copyright (c) 2001, 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.wst.xsd.ui.internal.common.properties.sections;

import org.eclipse.jface.window.Window;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.ui.IEditorPart;
import org.eclipse.wst.common.ui.internal.search.dialogs.ComponentSpecification;
import org.eclipse.wst.xsd.ui.internal.adt.edit.ComponentReferenceEditManager;
import org.eclipse.wst.xsd.ui.internal.adt.edit.IComponentDialog;
import org.eclipse.wst.xsd.ui.internal.common.commands.UpdateAttributeValueCommand;
import org.eclipse.wst.xsd.ui.internal.editor.Messages;
import org.eclipse.wst.xsd.ui.internal.editor.XSDSubstitutionGroupEditManager;
import org.eclipse.xsd.XSDElementDeclaration;
import org.eclipse.xsd.XSDSchema;
import org.eclipse.xsd.util.XSDConstants;
import org.w3c.dom.Element;

public class XSDElementDeclarationAdvancedSection extends AbstractSection
{
  private static final String EMPTY = ""; //$NON-NLS-1$
  private static final String FALSE = "false"; //$NON-NLS-1$
  private static final String TRUE = "true"; //$NON-NLS-1$
  protected CCombo blockCombo;
  protected CCombo finalCombo;
  protected CCombo abstractCombo;
  protected CCombo substGroupCombo;

  private String blockValues[] = { EMPTY, "#" + XSDConstants.ALL_ELEMENT_TAG, //$NON-NLS-1$
      XSDConstants.EXTENSION_ELEMENT_TAG, XSDConstants.RESTRICTION_ELEMENT_TAG,
      "substitution" }; //$NON-NLS-1$

  private String finalValues[] = { EMPTY, "#" + XSDConstants.ALL_ELEMENT_TAG, XSDConstants.EXTENSION_ELEMENT_TAG, //$NON-NLS-1$
      XSDConstants.RESTRICTION_ELEMENT_TAG }; //$NON-NLS-1$

  private String abstractValues[] = { EMPTY, TRUE, FALSE }; // TODO use some external string here instead

  protected void createContents(Composite parent)
  {
    composite = getWidgetFactory().createFlatFormComposite(parent);

    GridLayout gridLayout = new GridLayout();
    gridLayout.numColumns = 2;
    composite.setLayout(gridLayout);

    // ------------------------------------------------------------------
    // AbstractLabel
    // ------------------------------------------------------------------
    GridData data = new GridData();
    data.horizontalAlignment = GridData.HORIZONTAL_ALIGN_BEGINNING;
    data.grabExcessHorizontalSpace = false;

    // TODO Should be a translatable string here
    CLabel abstractLabel = getWidgetFactory().createCLabel(composite, XSDConstants.ABSTRACT_ATTRIBUTE + ":");
    abstractLabel.setLayoutData(data);

    // ------------------------------------------------------------------
    // AbstractCombo
    // ------------------------------------------------------------------
    data = new GridData();
    data.grabExcessHorizontalSpace = true;
    data.horizontalAlignment = GridData.FILL;
    abstractCombo = getWidgetFactory().createCCombo(composite);
    abstractCombo.setLayoutData(data);
    abstractCombo.setEditable(false);

    abstractCombo.setItems(abstractValues);
    abstractCombo.addSelectionListener(this);

    // ------------------------------------------------------------------
    // BlockLabel
    // ------------------------------------------------------------------
    data = new GridData();
    data.horizontalAlignment = GridData.HORIZONTAL_ALIGN_BEGINNING;
    data.grabExcessHorizontalSpace = false;

    // TODO Should be a translatable string here
    CLabel blockLabel = getWidgetFactory().createCLabel(composite, XSDConstants.BLOCK_ATTRIBUTE + ":");
    blockLabel.setLayoutData(data);

    // ------------------------------------------------------------------
    // BlockCombo
    // ------------------------------------------------------------------
    data = new GridData();
    data.grabExcessHorizontalSpace = true;
    data.horizontalAlignment = GridData.FILL;
    blockCombo = getWidgetFactory().createCCombo(composite);
    blockCombo.setLayoutData(data);
    blockCombo.setEditable(false);

    blockCombo.setItems(blockValues);
    blockCombo.addSelectionListener(this);

    // ------------------------------------------------------------------
    // FinalLabel
    // ------------------------------------------------------------------
    data = new GridData();
    data.horizontalAlignment = GridData.HORIZONTAL_ALIGN_BEGINNING;
    data.grabExcessHorizontalSpace = false;

    // TODO Should be a translatable string here
    CLabel finalLabel = getWidgetFactory().createCLabel(composite, XSDConstants.FINAL_ATTRIBUTE + ":");
    finalLabel.setLayoutData(data);

    // ------------------------------------------------------------------
    // FinalCombo
    // ------------------------------------------------------------------
    data = new GridData();
    data.grabExcessHorizontalSpace = true;
    data.horizontalAlignment = GridData.FILL;
    finalCombo = getWidgetFactory().createCCombo(composite);
    finalCombo.setLayoutData(data);
    finalCombo.setEditable(false);

    finalCombo.setItems(finalValues);
    finalCombo.addSelectionListener(this);

    // ------------------------------------------------------------------
    // Substitution Group Label
    // ------------------------------------------------------------------
    data = new GridData();
    data.horizontalAlignment = GridData.HORIZONTAL_ALIGN_BEGINNING;
    data.grabExcessHorizontalSpace = false;

    // TODO Should be a translatable string here
    CLabel subGroupLabel = getWidgetFactory().createCLabel(composite, XSDConstants.SUBSTITUTIONGROUP_ATTRIBUTE + ":");
    subGroupLabel.setLayoutData(data);

    // ------------------------------------------------------------------
    // Substitution Group Combo
    // ------------------------------------------------------------------
    data = new GridData();
    data.grabExcessHorizontalSpace = true;
    data.horizontalAlignment = GridData.FILL;
    substGroupCombo = getWidgetFactory().createCCombo(composite);
    substGroupCombo.setLayoutData(data);
    substGroupCombo.setEditable(true);
    substGroupCombo.addSelectionListener(this);
    applyAllListeners(substGroupCombo);
  }

  public void doHandleEvent(Event e)
  {
    if (e.widget == substGroupCombo)
    {
      XSDElementDeclaration eleDec = (XSDElementDeclaration) input;
      String value = substGroupCombo.getText();
      String oldValue = eleDec.getElement().getAttribute(XSDConstants.SUBSTITUTIONGROUP_ATTRIBUTE);
      if (oldValue == null)
        oldValue = EMPTY;
      if (value.equals(oldValue))
        return;

      UpdateAttributeValueCommand command = new UpdateAttributeValueCommand(eleDec.getElement(), XSDConstants.SUBSTITUTIONGROUP_ATTRIBUTE, value);
      command.setDeleteIfEmpty(true);
      getCommandStack().execute(command);
    }
  }

  public void doWidgetSelected(SelectionEvent e)
  {
    if (e.widget == blockCombo)
    {
      XSDElementDeclaration eleDec = (XSDElementDeclaration) input;
      String value = blockCombo.getText();

      UpdateAttributeValueCommand command = new UpdateAttributeValueCommand(eleDec.getElement(), XSDConstants.BLOCK_ATTRIBUTE, value);
      command.setDeleteIfEmpty(true);
      getCommandStack().execute(command);
    }
    else if (e.widget == finalCombo)
    {
      XSDElementDeclaration eleDec = (XSDElementDeclaration) input;
      String value = finalCombo.getText();

      UpdateAttributeValueCommand command = new UpdateAttributeValueCommand(eleDec.getElement(), XSDConstants.FINAL_ATTRIBUTE, value);
      command.setDeleteIfEmpty(true);
      getCommandStack().execute(command);
    }
    else if (e.widget == abstractCombo)
    {
      XSDElementDeclaration eleDec = (XSDElementDeclaration) input;
      String value = abstractCombo.getText();

      if (value.equals(EMPTY))
        eleDec.getElement().removeAttribute(XSDConstants.ABSTRACT_ATTRIBUTE);
      else
      {
        if (value.equals(TRUE))
          eleDec.setAbstract(true);
        else if (value.equals(FALSE))
          eleDec.setAbstract(false);
      }
    }
    else if (e.widget == substGroupCombo)
    {
      IEditorPart editor = getActiveEditor();
      if (editor == null) return;
      ComponentReferenceEditManager manager = (ComponentReferenceEditManager)editor.getAdapter(XSDSubstitutionGroupEditManager.class);    

      String selection = substGroupCombo.getText();
      ComponentSpecification newValue;
      IComponentDialog dialog= null;
      if ( selection.equals(Messages._UI_ACTION_BROWSE))
      {
        dialog = manager.getBrowseDialog();
      }
      else if ( selection.equals(Messages._UI_ACTION_NEW))
      {
        dialog = manager.getNewDialog();
      }

      if (dialog != null)
      {
        if (dialog.createAndOpen() == Window.OK)
        {
          newValue = dialog.getSelectedComponent();
          manager.modifyComponentReference(input, newValue);
        }
        else
        {
          substGroupCombo.setText("");
        }
      }
      else //use the value from selected quickPick item
      {
        newValue = getComponentSpecFromQuickPickForValue(selection, manager);
        if (newValue != null)
          manager.modifyComponentReference(input, newValue);
      }
    }
  }

  public void refresh()
  {
    super.refresh();
    fillSubstitutionGroupCombo();
    setListenerEnabled(false);
    try
    {
      if (input instanceof XSDElementDeclaration)
      {
        XSDElementDeclaration eleDec = (XSDElementDeclaration) input;

        composite.setEnabled(!isReadOnly);
        if (eleDec.getContainer() instanceof XSDSchema) // global element
        {
          abstractCombo.setEnabled(true);
          finalCombo.setEnabled(true);
          substGroupCombo.setEnabled(true);
        }
        else
        {
          abstractCombo.setEnabled(false);
          finalCombo.setEnabled(false);
          substGroupCombo.setEnabled(false);
        }

        Element element = eleDec.getElement();
        String blockAttValue = element.getAttribute(XSDConstants.BLOCK_ATTRIBUTE);
        if (blockAttValue != null)
        {
          blockCombo.setText(blockAttValue);
        }
        else
        {
          blockCombo.setText(EMPTY);
        }

        String finalAttValue = element.getAttribute(XSDConstants.FINAL_ATTRIBUTE);
        if (finalAttValue != null)
        {
          finalCombo.setText(finalAttValue);
        }
        else
        {
          finalCombo.setText(EMPTY);
        }

        if (element.hasAttribute(XSDConstants.ABSTRACT_ATTRIBUTE))
        {
          boolean absAttValue = eleDec.isAbstract();
          if (absAttValue)
            abstractCombo.setText(TRUE);
          else
            abstractCombo.setText(FALSE);
        }
        else
          abstractCombo.setText(EMPTY);

        if (element.hasAttribute(XSDConstants.SUBSTITUTIONGROUP_ATTRIBUTE))
        {
          substGroupCombo.setText(element.getAttribute(XSDConstants.SUBSTITUTIONGROUP_ATTRIBUTE));
        }
        else
        {
          substGroupCombo.setText(EMPTY);
        }
      }
    }
    catch (Exception e)
    {
    }
    setListenerEnabled(true);
  }
  
  private void fillSubstitutionGroupCombo()
  {
    IEditorPart editor = getActiveEditor();
    ComponentReferenceEditManager manager = (ComponentReferenceEditManager)editor.getAdapter(XSDSubstitutionGroupEditManager.class);    
    ComponentSpecification[] items = manager.getQuickPicks();
    
    substGroupCombo.removeAll();
    substGroupCombo.add(Messages._UI_ACTION_BROWSE);
    substGroupCombo.add(Messages._UI_ACTION_NEW);
    for (int i = 0; i < items.length; i++)
    {
      substGroupCombo.add(items[i].getName());
    }
    // Add the current substitution group if needed
    XSDElementDeclaration namedComponent = ((XSDElementDeclaration) input).getSubstitutionGroupAffiliation();
    if (namedComponent != null)
    {  
      ComponentSpecification ret = getComponentSpecFromQuickPickForValue(namedComponent.getName(),manager);
      if (ret == null)
      {
        substGroupCombo.add(namedComponent.getQName(xsdSchema));
      }
    } 
  }
  
  private ComponentSpecification getComponentSpecFromQuickPickForValue(String value, ComponentReferenceEditManager editManager)
  {
    if (editManager != null)
    {  
      ComponentSpecification[] quickPicks = editManager.getQuickPicks();
      if (quickPicks != null)
      {
        for (int i=0; i < quickPicks.length; i++)
        {
          ComponentSpecification componentSpecification = quickPicks[i];
          if (value != null && value.equals(componentSpecification.getName()))
          {
            return componentSpecification;
          }                
        }  
      }
    }
    return null;
  }

}
