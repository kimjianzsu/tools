package org.eclipse.wst.xsd.ui.internal.adt.editor;

public interface IEditorModeListener
{
  void editorModeChanged(EditorMode newEditorMode);
}
