/**
* <copyright>
*
* Licensed Material - Property of IBM
* (C) Copyright IBM Corp. 2002 - All Rights Reserved.
* US Government Users Restricted Rights - Use, duplication or disclosure
* restricted by GSA ADP Schedule Contract with IBM Corp.
*
* </copyright>
*
* File plugins/com.ibm.etools.webservice.explorer/wsexplorer/src/com/ibm/etools/webservice/explorer/wsdl/fragment/IXSDElementFragment.java, wsa.etools.ws.explorer, lunar-5.1.2, 20031231a 1
* Version 1.1 03/02/28 15:26:05
*/
package org.eclipse.wst.ws.internal.explorer.platform.wsdl.fragment;

public interface IXSDAttributeFragment extends IXSDDelegationFragment {
  
  
  
}
