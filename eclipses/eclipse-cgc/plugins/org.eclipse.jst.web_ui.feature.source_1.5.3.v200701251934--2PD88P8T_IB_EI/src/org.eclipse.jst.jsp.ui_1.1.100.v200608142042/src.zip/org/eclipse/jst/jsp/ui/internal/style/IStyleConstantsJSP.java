package org.eclipse.jst.jsp.ui.internal.style;

public interface IStyleConstantsJSP {
	public static final String JSP_CONTENT = "jsp_content"; //$NON-NLS-1$
}
