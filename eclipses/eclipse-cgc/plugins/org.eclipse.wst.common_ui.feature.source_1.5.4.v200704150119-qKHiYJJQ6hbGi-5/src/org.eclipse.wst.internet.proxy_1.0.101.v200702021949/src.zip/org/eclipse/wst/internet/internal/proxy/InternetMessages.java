/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.internet.internal.proxy;

import org.eclipse.osgi.util.NLS;

public final class InternetMessages extends NLS {

	private static final String BUNDLE_NAME = "org.eclipse.wst.internet.internal.proxy.internet";//$NON-NLS-1$

	private InternetMessages() {
		// Do not instantiate
	}

  public static String LABEL_PROXY_SERVER;
  public static String CHECKBOX_PREFERENCE_ENABLE_PROXY;
  public static String LABEL_PREFERENCE_HOSTNAME;
  public static String LABEL_PREFERENCE_PORT;
  public static String LABEL_PREFERENCE_USERNAME;
  public static String LABEL_PREFERENCE_PASSWORD;
  public static String CHECKBOX_PREFERENCE_ENABLE_NAME;
  public static String CHECKBOX_PREFERENCE_USE_SOCKS;
  public static String LABEL_PREFERENCE_NON_PROXY_HOSTNAMES;
  public static String BUTTON_PREFERENCE_ADD;
  public static String BUTTON_PREFERENCE_EDIT;
  public static String BUTTON_PREFERENCE_REMOVE;
  public static String TITLE_PREFERENCE_HOSTS_DIALOG;
  public static String LABEL_PREFERENCE_HOSTS_DIALOG;
  
  public static String TITLE_PASSWORD_DIALOG_TITLE;
  public static String LABEL_USERNAME;
  public static String LABEL_PASSWORD;
  
	static {
		NLS.initializeMessages(BUNDLE_NAME, InternetMessages.class);
	}
}
