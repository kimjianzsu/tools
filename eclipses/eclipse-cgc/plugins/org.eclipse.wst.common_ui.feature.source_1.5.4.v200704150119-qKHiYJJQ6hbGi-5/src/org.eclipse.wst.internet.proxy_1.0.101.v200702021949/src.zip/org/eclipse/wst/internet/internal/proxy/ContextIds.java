/*******************************************************************************
 * Copyright (c) 2000, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 * IBM Corporation - initial API and implementation
 ******************************************************************************/

package org.eclipse.wst.internet.internal.proxy;

public interface ContextIds {
	// Constant for the Internet plug-in id.
	public static final String PLUGIN_ID = InternetPlugin.ID;

	// Context help ID constants for the Internet preference page.
	public static final String INTERNET_PREF_PROXY = PLUGIN_ID + ".inpp0010";
	public static final String INTERNET_PREF_PROXY_HOST = PLUGIN_ID + ".inpp0020";
	public static final String INTERNET_PREF_PROXY_PORT = PLUGIN_ID + ".inpp0030";
	public static final String INTERNET_PREF_SOCKS = PLUGIN_ID + ".inpp0040";
	public static final String INTERNET_PREF_AUTHENTICATION = PLUGIN_ID + ".inpp0110";
	public static final String INTERNET_PREF_USERNAME = PLUGIN_ID + ".inpp0120";
	public static final String INTERNET_PREF_PASSWORD = PLUGIN_ID + ".inpp0130";
  public static final String INTERNET_PREF_NON_PROXY_HOSTS = PLUGIN_ID + ".inpp0140";
}