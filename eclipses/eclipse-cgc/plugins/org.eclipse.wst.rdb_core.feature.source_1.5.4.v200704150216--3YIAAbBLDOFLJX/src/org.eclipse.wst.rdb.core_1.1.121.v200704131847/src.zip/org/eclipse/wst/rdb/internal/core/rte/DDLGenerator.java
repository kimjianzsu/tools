/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.internal.core.rte;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.wst.rdb.internal.models.sql.schema.SQLObject;

public interface DDLGenerator {
	public String[] generateDDL(SQLObject[] elements, IProgressMonitor progressMonitor);
    public String[] createSQLObjects(SQLObject[] elements, boolean quoteIdentifiers, boolean qualifyNames, IProgressMonitor progressMonitor);
    public String[] dropSQLObjects(SQLObject[] elements, boolean quoteIdentifiers, boolean qualifyNames, IProgressMonitor progressMonitor);
	public EngineeringOption[] getOptions();
    public EngineeringOption[] getOptions(SQLObject[] elements); //@d00058820gs
    public EngineeringOption[] getOptions(SQLObject[] elements, boolean autoDiscovery); //@d00058820gs
    public EngineeringOptionCategory[] getOptionCategories();
}
