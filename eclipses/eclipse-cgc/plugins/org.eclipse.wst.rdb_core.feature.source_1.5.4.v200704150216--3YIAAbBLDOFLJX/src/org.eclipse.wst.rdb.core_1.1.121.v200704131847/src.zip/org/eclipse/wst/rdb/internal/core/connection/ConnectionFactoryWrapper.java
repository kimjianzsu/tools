/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.internal.core.connection;

import java.sql.Connection;
import java.sql.Driver;

public class ConnectionFactoryWrapper implements ConnectionFactory2{
	ConnectionFactory factory = null;
	
	public ConnectionFactoryWrapper(ConnectionFactory factory){
		this.factory = factory;
	}
	
	public Connection connect(Driver driver, ClassLoader loader, ConnectionInfo info) throws Exception {
		return this.factory.connect(driver, loader, info.getURL(), info.getProperties());
	}

}
