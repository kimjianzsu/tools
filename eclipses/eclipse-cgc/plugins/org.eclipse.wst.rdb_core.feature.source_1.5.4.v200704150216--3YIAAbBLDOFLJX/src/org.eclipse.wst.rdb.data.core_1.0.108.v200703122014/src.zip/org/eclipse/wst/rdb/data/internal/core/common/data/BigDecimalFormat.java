/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.wst.rdb.data.internal.core.common.data;

import java.math.BigDecimal;

import com.ibm.icu.text.DecimalFormat;
import com.ibm.icu.text.DecimalFormatSymbols;
import com.ibm.icu.text.NumberFormat;

public class BigDecimalFormat
{
	protected NumberFormat nf;
	protected static BigDecimalFormat instance = null;
	
	protected BigDecimalFormat()
	{
		nf = NumberFormat.getNumberInstance();
	}
	
	public static BigDecimalFormat getInstance()
	{
		if (instance==null)
			instance = new BigDecimalFormat();
		
		return instance;
	}
	
	public String format(BigDecimal bd)
	{
		String s = bd.toString();
		
		if (nf instanceof DecimalFormat) {
			DecimalFormatSymbols symbols = ((DecimalFormat)nf).getDecimalFormatSymbols();
			s = s.replace('.', symbols.getDecimalSeparator());
			s = s.replace('-', symbols.getMinusSign());
		}
		
		return s;
	}
	
	public BigDecimal parse(String s)
	{
		if (nf instanceof DecimalFormat) {
			DecimalFormatSymbols symbols = ((DecimalFormat)nf).getDecimalFormatSymbols();
			s = s.replace(symbols.getDecimalSeparator(), '.');
			s = s.replace(symbols.getMinusSign(), '-');
		}
		
		return new BigDecimal(s);
	}
}
