/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.data.internal.core.common;

/**
 * @author groux
 */
public interface Output {

    //  Status (match constants in OutputItem)
    public static final int STATUS_SUCCESS = 2;
    public static final int STATUS_WARNING = 3;
    public static final int STATUS_FAILURE = 4;
    public static final int STATUS_CRITICAL_ERROR = 6;
    
    public void write(String s);
    
}
