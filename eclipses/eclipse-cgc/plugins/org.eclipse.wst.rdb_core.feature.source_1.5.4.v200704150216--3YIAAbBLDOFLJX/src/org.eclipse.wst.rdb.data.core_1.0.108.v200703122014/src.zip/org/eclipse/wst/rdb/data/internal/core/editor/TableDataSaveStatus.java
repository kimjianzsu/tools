/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.wst.rdb.data.internal.core.editor;


public class TableDataSaveStatus {

    public int inserted = 0;
    public int updated = 0;
    public int deleted = 0;
    
    public boolean duplicateRow = false;
    
    public void reset()
    {
        inserted = 0;
        updated = 0;
        deleted = 0;
        duplicateRow = false;
    }
}
