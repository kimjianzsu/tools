/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.server.extensions.internal.actions;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.action.IAction;
import org.eclipse.wst.rdb.server.extensions.internal.ServerExtensionsPlugin;

/**
 * @author groux
 */
public class SQLTemplateAction extends Action {

	
	public void run(IAction action)
	{
	      try {
	         init();
	         openSQLTemplate();
	      }
	      catch (Exception e) {
	         ServerExtensionsPlugin.getDefault().writeLog(IStatus.ERROR, 0, e.getMessage(), e);
	      }
		
	}

	
	

}
