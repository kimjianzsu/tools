/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.server.extensions.internal.util;

public class DatabaseTypes {

   public final static int SQL_SERVER = 1;
   public final static int ORACLE     = 2;
   public final static int DB2        = 3;
   public final static int SYBASE     = 4;
   public final static int SQL99      = 5;
   public final static int INFORMIX   = 6;
   public final static int DERBY      = 7;

}