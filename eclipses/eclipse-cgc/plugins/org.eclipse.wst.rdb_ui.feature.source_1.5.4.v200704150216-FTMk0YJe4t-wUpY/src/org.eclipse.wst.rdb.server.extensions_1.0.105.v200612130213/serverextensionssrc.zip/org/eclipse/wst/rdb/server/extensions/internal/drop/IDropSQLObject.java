/*******************************************************************************
 * Copyright (c) 2000, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.server.extensions.internal.drop;

import org.eclipse.wst.rdb.internal.models.sql.schema.SQLObject;

public interface IDropSQLObject {

   void dropSQLObject(SQLObject sqlObject);
}
