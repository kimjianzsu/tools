/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.connection.internal.ui.wizards;



/**
 * Adds or edits a filter element.
 */
public class NewCWAddFilterDialog {}

//extends Dialog implements Listener
//{
//	public static final int CONTEXT_SCHEMA  = 1;
//	public static final int CONTEXT_TABLE   = 2;
//	public static final int CONTEXT_ROUTINE = 4;
//	
//	/** Options for configuring the content of this page. */
//   protected int contentOptions;
//
//   /** False if we are adding; true if we are editing. */
//	protected boolean editing;
//	/** Our context: schema or object. */
//	protected int context;
//	/** We are launched from a wizard page. */
//	protected RDBWizardPage parentPage;
//	
//	/** Check for whether the filter is enabled. Available only if editing. */
//	protected Button enabledCheck;
//	/** Choice of the filter target. */
//	protected Combo targetCombo;
//	/** Choice of predicate. */
//	protected Combo predCombo;
//	/** Choice of text. */
//	protected Combo filterCombo;
//	/* Choice of AND or OR. */
//	//protected Combo operatorCombo;
//
//   /** Target choices. */
//   protected String[] targetStates;
//	/** Current choice for enabled checkbox. */
//	protected boolean enabledResult = true;	
//	/** Current choice for the target. */
//	protected String targetResult;
//	/** Current choice for the predicate. */
//	protected String predicateResult;
//	/** Current choice for the filter text. */
//	protected String filterResult;
//	/* Current choice for the operator. */
//	//protected String operatorResult;
//	/** The initial target, given by the caller. */
//	//protected String initialTarget;
//	
//	/**
//	 * Constructor for AddFilterDialog.
//	 * @param parentShell The Shell.
//	 * @param parentPage The filter page of the wizard.
//	 * @param adding True if we are adding; false if we are editing.
//	 * @param context Code indicating schema, table, or routine.
//	 */
//	public NewCWAddFilterDialog(Shell parentShell,
//            RDBWizardPage parentPage, boolean adding, int context,
//            int contentOptions)
//   {
//		this(parentShell, parentPage, adding, context, contentOptions,
//         new String[]{parentPage.getString("CUI_NEWCW_FILTER_SCOPE_SCHEMA_UI_")});
//	}
//   public NewCWAddFilterDialog(Shell parentShell,
//            RDBWizardPage parentPage, boolean adding, int context,
//            int contentOptions, String[] targetStates)
//   {
//      super(parentShell);
//      setShellStyle(SWT.RESIZE | SWT.TITLE | SWT.CLOSE | SWT.BORDER | SWT.SYSTEM_MODAL);
//      setBlockOnOpen(true);
//      this.editing = !adding;
//      this.context = context;
//      this.parentPage = parentPage;
//      this.contentOptions = contentOptions;
//      this.targetStates = targetStates;
////    initialTarget = parentPage.getString("CUI_DBAFILTERGROUP_TARGET2_UI_");
//   }
//	
//	protected void configureShell(Shell shell) {
//		super.configureShell(shell);
//		if (editing)
//		{
//			if (context == CONTEXT_SCHEMA)
//			{
//				shell.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_SCHEMA_EDITTITLE_UI_"));
//			}
//			else
//			{
//				shell.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_OBJECT_EDITTITLE_UI_"));
//			}
//		}
//		else
//		{
//			if (context == CONTEXT_SCHEMA)
//			{
//				shell.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_SCHEMA_ADDTITLE_UI_"));
//			}
//			else
//			{
//				shell.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_OBJECT_ADDTITLE_UI_"));
//			}
//		}
//	}
//	
//	protected Control createContents(Composite parent)
//	{
//		Control control = super.createContents(parent);
//		getButton(IDialogConstants.OK_ID).setEnabled(determineValidity());
//		return control;
//	}
//	
//	protected Control createDialogArea(Composite parent)
//	{
//		RSCCoreUIWidgetFactory factory = NewConnectionWizard.getUIFactory();
//		// Main panel
//		Composite composite = (Composite) super.createDialogArea(parent);
//		GridLayout layout = new GridLayout();
//		layout.numColumns = 2;
//		composite.setLayout(layout);
//		GridData gd;
//		// Description
//		Label desc = factory.createLabel(composite, SWT.NONE);
//		if (context == CONTEXT_SCHEMA)
//			desc.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_SCHEMA_DESC_UI_"));
//		else
//			desc.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_OBJECT_DESC_UI_"));
//		gd = new GridData();
//		gd.verticalAlignment = GridData.BEGINNING;
//		gd.horizontalSpan = 2;
//		desc.setLayoutData(gd);
//		if (editing)
//		{
//			// Enabled
//			enabledCheck = factory.createButton(composite, SWT.CHECK);
//			enabledCheck.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_ENABLED_UI_"));
//			gd = new GridData();
//			gd.verticalAlignment = GridData.BEGINNING;
//			gd.horizontalSpan = 2;
//			enabledCheck.setLayoutData(gd);
//		}
//		// Scope label
//		Label scopeLabel = factory.createLabel(composite, SWT.NONE);
//		scopeLabel.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_TARGET_UI_"));
//		gd = new GridData();
//		gd.verticalAlignment = GridData.BEGINNING;
//		scopeLabel.setLayoutData(gd);
//		// Scope combo
//		targetCombo = factory.createCombo(composite, SWT.BORDER | SWT.READ_ONLY);
//		gd = new GridData();
//		gd.verticalAlignment = GridData.BEGINNING;
//		gd.horizontalAlignment = GridData.FILL;
//		gd.grabExcessHorizontalSpace = true;
//		targetCombo.setLayoutData(gd);
//      /*
//      boolean showCombinedTargets = ((contentOptions & NewConnectionWizard.SHOW_COMBINED_FILTERS) == NewConnectionWizard.SHOW_COMBINED_FILTERS);
//      switch (context) {
//			case CONTEXT_SCHEMA:
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_SCHEMA_UI_"));
//				break;
//			case CONTEXT_TABLE:
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_TABLE_UI_"));
//            if (showCombinedTargets)
//               targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_ALLDATA_UI_"));
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_VIEW_UI_"));
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_ALIAS_UI_"));
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_NICKNAME_UI_"));
//				//targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_SYNONYM_UI_"));
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_MQT_UI_"));
//            if (showCombinedTargets)
//            {
//   				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_TABLEVIEW_UI_"));
//   				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_VIEWALIASNICK_UI_"));
//   				//targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_VIEWALIASSYN_UI_"));
//            }
//            break;
//			default: // Routine
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_SP_UI_"));
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_UDF_UI_"));
//				targetCombo.add(parentPage.getString("CUI_NEWCW_FILTER_SCOPE_SPUDF_UI_"));
//			break;
//		}
//      */
//      for (int s = 0; s < targetStates.length; s++)
//         targetCombo.add(targetStates[s]);
//		if (context == CONTEXT_SCHEMA)
//			targetCombo.setEnabled(false);
//		
//		// Predicate
//		Label predLabel = factory.createLabel(composite, SWT.NONE);
//		predLabel.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_PREDICATE_UI_"));
//		gd = new GridData();
//		gd.verticalAlignment = GridData.BEGINNING;
//		predLabel.setLayoutData(gd);
//		
//		predCombo = factory.createCombo(composite, SWT.BORDER | SWT.READ_ONLY);
//		gd = new GridData();
//		gd.verticalAlignment = GridData.BEGINNING;
//		gd.horizontalAlignment = GridData.FILL;
//		gd.grabExcessHorizontalSpace = true;
//		gd.widthHint = 200;
//		predCombo.setLayoutData(gd);
//		predCombo.add(parentPage.getString("CUI_NEWCW_ADDFILTER_PREDICATE_LIKE_UI_"));
//		predCombo.add(parentPage.getString("CUI_NEWCW_ADDFILTER_PREDICATE_NOTLIKE_UI_"));
//		
//		// Filter		
//		Label filterLabel = factory.createLabel(composite, SWT.NONE);
//		filterLabel.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_FILTER_UI_"));
//		gd = new GridData();
//		gd.verticalAlignment = GridData.BEGINNING;
//		filterLabel.setLayoutData(gd);
//		
//		filterCombo = factory.createCombo(composite, SWT.BORDER);
//		gd = new GridData();
//		gd.verticalAlignment = GridData.BEGINNING;
//		gd.horizontalAlignment = GridData.FILL;
//		gd.grabExcessHorizontalSpace = true;
//		gd.widthHint = 200;
//		filterCombo.setLayoutData(gd);
//		/*
//		if (editing)
//		{
//			// Operator		
//			Label operatorLabel = factory.createLabel(composite, SWT.NONE);
//			operatorLabel.setText(parentPage.getString("CUI_NEWCW_ADDFILTER_OPERATOR_UI_"));
//			gd = new GridData();
//			gd.verticalAlignment = GridData.BEGINNING;
//			operatorLabel.setLayoutData(gd);
//			
//			operatorCombo = factory.createCombo(composite, SWT.BORDER | SWT.READ_ONLY);
//			gd = new GridData();
//			gd.verticalAlignment = GridData.BEGINNING;
//			gd.horizontalAlignment = GridData.FILL;
//			gd.grabExcessHorizontalSpace = true;
//			gd.widthHint = 200;
//			operatorCombo.setLayoutData(gd);
//         operatorCombo.add(parentPage.getString("CUI_DBAFILTERGROUP_OPERATOR_AND_UI_"));
//         operatorCombo.add(parentPage.getString("CUI_DBAFILTERGROUP_OPERATOR_OR_UI_"));
//			
//			// Set values from the caller
//			if (operatorResult != null)
//				operatorCombo.select(operatorCombo.indexOf(operatorResult));
//			else
//				operatorCombo.select(0);
//		}
//		*/
//      if (editing)
//      {
//         enabledCheck.setSelection(enabledResult);
//      }
//      //if (initialTarget != null)
//		//	targetCombo.select(targetCombo.indexOf(initialTarget));
//		if (targetResult != null)
//			targetCombo.select(targetCombo.indexOf(targetResult));
//		else
//			targetCombo.select(0);
//			
//		if (predicateResult != null)
//			predCombo.select(predCombo.indexOf(predicateResult));
//		else
//			predCombo.select(0);
//		//predCombo.indexOf(parentPage.getString("CUI_NEWCW_ADDFILTER_OPER_LIKE_UI_")));
//
//      // filterCombo has a history in the dialog settings
//		IDialogSettings dialogSettings = parentPage.getWizard().getDialogSettings();
//      if (dialogSettings != null)
//      {
//         String setting = NewConnectionWizard.STORE_SCHEMA_FILTERS;
//         if (context == CONTEXT_TABLE)
//            setting = NewConnectionWizard.STORE_TABLE_FILTERS;
//         else if (context == CONTEXT_ROUTINE)
//            setting = NewConnectionWizard.STORE_ROUTINE_FILTERS;
//         String[] values = dialogSettings.getArray(setting);
//         if (values != null)
//         {
//         	parentPage.loadComboSettings(filterCombo, values, false);
//         }
//      }
//		if (filterResult != null)
//			filterCombo.setText(filterResult);
//		else
//			filterCombo.setText("");
//
//		targetResult = targetCombo.getText();
//		predicateResult = predCombo.getText();
//		
//		filterCombo.setFocus();
//		
//		addWorkbenchHelp(parent);
//		addListeners();
//		return parent;
//	}
//	
//	/**
//	 * Adds workbench help to various components.
//	 */
//	protected void addWorkbenchHelp(Composite parent)
//	{
//		if (editing)
//		{
//			WorkbenchHelp.setHelp(
//				enabledCheck,
//				RSCCommonUIContextIds.RSC_NEWCW_FILTER_ADDFILTER_ENABLED);
//			//WorkbenchHelp.setHelp(
//			//	operatorCombo,
//			//	RSCCommonUIContextIds.RSC_NEWCW_FILTER_ADDFILTER_OPERATOR);
//		}
//		WorkbenchHelp.setHelp(
//				targetCombo,
//				RSCCommonUIContextIds.RSC_NEWCW_FILTER_ADDFILTER_TARGET);
//		WorkbenchHelp.setHelp(
//				predCombo,
//				RSCCommonUIContextIds.RSC_NEWCW_FILTER_ADDFILTER_PREDICATE);
//		WorkbenchHelp.setHelp(
//				filterCombo,
//				RSCCommonUIContextIds.RSC_NEWCW_FILTER_ADDFILTER_NAME);
//	}
//	
//	/**
//	 * Adds this as listener to various components.
//	 */
//	public void addListeners()
//	{
//		if (editing)
//		{
//			enabledCheck.addListener(SWT.Selection, this);
//			//operatorCombo.addListener(SWT.Modify, this);
//		}
//		targetCombo.addListener(SWT.Modify, this);
//		predCombo.addListener(SWT.Modify, this);
//		filterCombo.addListener(SWT.Modify, this);
//	}
//	
//	public void handleEvent(Event e) {
//		Widget source = e.widget;
//		if (enabledCheck != null && source == enabledCheck)
//		{
//			enabledResult = enabledCheck.getSelection();
//		}
//		else if (source == filterCombo)
//		{
//			filterResult = filterCombo.getText();
//			getButton(IDialogConstants.OK_ID).setEnabled(determineValidity());
//		}
//		else if (source == targetCombo)
//		{
//			targetResult = targetCombo.getText();
//		}
//		else if (source == predCombo)
//		{
//			predicateResult = predCombo.getText();
//		}
//		//else if (source == operatorCombo)
//		//{
//		//	operatorResult = operatorCombo.getText();
//		//}
//	}
//
//   protected boolean determineValidity()
//   {
//   	return (filterCombo.getText().length() != 0);
//   }
//	
//	public boolean getEnabledResult()
//	{
//		return enabledResult;
//	}
//	public String getTargetResult()
//	{
//		return targetResult;
//	}
//	public String getPredicateResult()
//	{
//		return predicateResult;
//	}
//	public String getFilterResult()
//	{
//		return filterResult;
//	}
//	//public String getOperatorResult()
//	//{
//	//	return operatorResult;
//	//}
//	
//	public void setEnabled(boolean enabled)
//	{
//		enabledResult = enabled;
//	}
//	public void setTarget(String target)
//	{
//		//this.initialTarget = target;
//		targetResult = target;
//	}
//	public void setPredicate(String predicate)
//	{
//		//this.initialPredicate = predicate;
//		predicateResult = predicate;
//	}
//	public void setFilter(String filter)
//	{
//		//this.initialFilter = filter;
//		filterResult = filter;
//	}
//	//public void setOperator(String oper)
//	//{
//	//	operatorResult = oper;
//	//}
//
//	/**
//	 * Overrides okPressed to save dialog settings
//    * @see org.eclipse.jface.dialogs.Dialog#okPressed()
//	 */
//	protected void okPressed()
//    {
//		IDialogSettings dialogSettings = parentPage.getWizard().getDialogSettings();
//		if (dialogSettings != null)
//		{
//			// update filter history
//         String setting = NewConnectionWizard.STORE_SCHEMA_FILTERS;
//         if (context == CONTEXT_TABLE)
//            setting = NewConnectionWizard.STORE_TABLE_FILTERS;
//         else if (context == CONTEXT_ROUTINE)
//            setting = NewConnectionWizard.STORE_ROUTINE_FILTERS;
//			String[] filters = dialogSettings.getArray(setting);
//			filters = parentPage.addToHistory(filters, filterCombo.getText().trim());
//			dialogSettings.put(setting, filters);
//		}
//		super.okPressed();
//	}
//}
