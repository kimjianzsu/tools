/*******************************************************************************
 * Copyright (c) 2005 IBM Corporation and others. All rights reserved. This
 * program and the accompanying materials are made available under the terms of
 * the Eclipse Public License v1.0 which accompanies this distribution, and is
 * available at http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/

package org.eclipse.wst.rdb.connection.internal.ui.wizards.shared;

public class DatabaseProductVersion {
    private String product;

    private String version;

    public DatabaseProductVersion(String product, String version) {
        this.product = product;
        this.version = version;

    }

    /**
     * @param product
     *            The product to set.
     */
    public void setProduct(String product) {
        this.product = product;
    }

    /**
     * @return Returns the product.
     */
    public String getProduct() {
        return product;
    }

    /**
     * @param version
     *            The version to set.
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * @return Returns the version.
     */
    public String getVersion() {
        return version;
    }
}