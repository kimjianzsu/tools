/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.connection.internal.ui.filter;

import java.util.Vector;

import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.wst.rdb.connection.internal.ui.Workbook;


public class SWWorkbook extends Workbook {

	/**
	 * SWWorkbook constructor comment.
	 * @param parent org.eclipse.swt.widgets.Composite
	 */
	protected Vector pages;
	public SWWorkbook(org.eclipse.swt.widgets.Composite parent) {
		super(parent);
		pages = super.pages;
	}
	
	public TabFolder getTabFolder() {
		return (TabFolder) getClientComposite().getParent();
	}
	/**
	 * Insert the method's description here.
	 * Creation date: (03/16/01 4:48:11 PM)
	 */
	public void removeAllTabs() {

		TabItem[] ti = getTabFolder().getItems();
		int numItems = ti.length;
		for (int i = 0; i < numItems; i++) {
			ti[i].dispose();
			pages.remove(0);
		}

	}
}
