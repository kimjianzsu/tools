/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.connection.internal.ui.factories;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;

public class RSCCoreUIWidgetFactory
{
    public static final RSCCoreUIWidgetFactory INSTANCE = new RSCCoreUIWidgetFactory();

    private RSCCoreUIWidgetFactory()
    {
    }

    public Button createButton(Composite parent, String text, int style)
    {
        Button button = new Button(parent, style);
        if (text != null)
        {
            button.setText(text);
        }
        button.setFont(parent.getFont());
        return button;
    }

    public Button createButton(Composite parent, int style)
    {
        Button button = new Button(parent, style);
        button.setFont(parent.getFont());
        return button;
    }

    public Composite createComposite(Composite parent, int style)
    {
        Composite composite = new Composite(parent, style);
        composite.setFont(parent.getFont());
        return composite;
    }

    public Label createLabel(Composite parent, String text, int style)
    {
        Label label = new Label(parent, style);
        if (text != null)
            label.setText(text);
        label.setFont(parent.getFont());
        return label;
    }

    public Label createLabel(Composite parent, int style)
    {
        Label label = new Label(parent, style);
        label.setFont(parent.getFont());
        return label;
    }

    public Label createSeparator(Composite parent, int style)
    {
        return createLabel(parent, SWT.SEPARATOR | style);
    }

    public Text createText(Composite parent, String value, int style)
    {
        Text text = new Text(parent, style);
        if (value != null)
            text.setText(value);
        text.setFont(parent.getFont());
        return text;
    }

    public Text createText(Composite parent, int style)
    {
        Text text = new Text(parent, style);
        text.setFont(parent.getFont());
        return text;
    }

    public ScrolledComposite createScrolledComposite(Composite parent, int style)
    {
        ScrolledComposite composite = new ScrolledComposite(parent, style);
        composite.setFont(parent.getFont());
        return composite;
    }

    public Group createGroup(Composite parent, String text, int style)
    {
        Group groupWidget = new Group(parent, style);
        if (text != null)
            groupWidget.setText(text);
        groupWidget.setFont(parent.getFont());
        return groupWidget;
    }

    public Group createGroup(Composite parent, int style)
    {
        Group groupWidget = new Group(parent, style);
        groupWidget.setFont(parent.getFont());
        return groupWidget;
    }

    public Combo createCombo(Composite parent, int style)
    {
        Combo combo = new Combo(parent, style);
        combo.setFont(parent.getFont());
        return combo;
    }

    public List createList(Composite parent, int style)
    {
        List list = new List(parent, style);
        list.setFont(parent.getFont());
        return list;
    }

    public Tree createTree(Composite parent, int style)
    {
        Tree tree = new Tree(parent, style);
        tree.setFont(parent.getFont());
        return tree;
    }

    /**
     * Creates a Table with the paren't font.
     * 
     * @param parent
     *            The parent Composite.
     * @param style
     *            SWT style flags for the Table constructor.
     */
    public Table createTable(Composite parent, int style)
    {
        Table table = new Table(parent, style);
        table.setFont(parent.getFont());
        return table;
    }
}
