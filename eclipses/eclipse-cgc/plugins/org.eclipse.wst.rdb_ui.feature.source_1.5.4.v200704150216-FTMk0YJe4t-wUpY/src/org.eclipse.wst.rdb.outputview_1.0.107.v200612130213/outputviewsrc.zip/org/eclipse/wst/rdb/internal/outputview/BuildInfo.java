/*******************************************************************************
* Copyright (c) 2000, 2004 IBM Corporation and others.
* All rights reserved. This program and the accompanying materials
* are made available under the terms of the Eclipse Public License v1.0
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v10.html
*
* Contributors:
*     IBM Corporation - initial API and implementation
*******************************************************************************/
package org.eclipse.wst.rdb.internal.outputview;

/**
 * Contains the build level.
 */
public class BuildInfo 
{
   public static final String fgBuildLevel = "20031104_1915-WB212-AD-V511D-W5";
   public static String level() { return fgBuildLevel; }
   public static String getWSABuildLevel() { return fgBuildLevel; }
}
