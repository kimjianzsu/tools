/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.fe.internal.ui.wizards;

import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.util.List;
import java.util.Vector;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.wst.rdb.connection.internal.ui.wizards.shared.DatabaseAuthenticationWizardPage;
import org.eclipse.wst.rdb.connection.internal.ui.wizards.shared.DatabaseProductVersion;
import org.eclipse.wst.rdb.core.internal.ui.icons.ImageDescription;
import org.eclipse.wst.rdb.fe.internal.ui.util.ResourceLoader;
import org.eclipse.wst.rdb.internal.core.RDBCorePlugin;
import org.eclipse.wst.rdb.internal.core.connection.ConnectionInfo;
import org.eclipse.wst.rdb.internal.core.connection.ConnectionManager;
import org.eclipse.wst.rdb.internal.core.definition.DatabaseDefinition;
import org.eclipse.wst.rdb.internal.core.rte.DDLGenerator;
import org.eclipse.wst.rdb.internal.core.rte.EngineeringOption;
import org.eclipse.wst.rdb.internal.core.util.DatabaseProviderHelper;
import org.eclipse.wst.rdb.internal.core.util.SaveDDLUtility;
import org.eclipse.wst.rdb.internal.models.sql.schema.Database;
import org.eclipse.wst.rdb.internal.models.sql.schema.SQLObject;
import org.eclipse.wst.rdb.server.internal.ui.query.execute.QueryOutputHelper;
import org.eclipse.wst.rdb.sqleditor.internal.SQLEditorFileEditorInput;

/**
 * @author ldunnell
 */
public class FEWizard extends Wizard implements IGenerateDDL{

    private FESelectOptionsWizardPage selectOptionsPage;
    
    private FESelectObjectsWizardPage selectObjectsPage;

    private FESelectFileWizardPage selectFilePage;

    private FESpecifyExistingConnectionsWizardPage existingConnectionsPage;

    private DatabaseAuthenticationWizardPage databaseAuthenticationPage;

    private FEConfigureJDBCConnectionWizardPage configureJDBCPage;

    private FESummaryWizardPage summaryPage;

    private static String SELECT_OPTIONS_WIZARD_PAGE_NAME = "com.ibm.datatools.modeler.fe.ui.wizards.SelectOptionsPage"; //$NON-NLS-1$

    private static String SELECT_OBJECTS_WIZARD_PAGE_NAME = "com.ibm.datatools.modeler.fe.ui.wizards.SelectObjectsPage"; //$NON-NLS-1$
    
    private static String SELECT_FILE_WIZARD_PAGE_NAME = "com.ibm.datatools.modeler.fe.ui.wizards.SelectFilePage"; //$NON-NLS-1$

    private static String EXISTING_CONNECTIONS_WIZARD_PAGE_NAME = "com.ibm.datatools.modeler.fe.ui.wizards.ExistingConnectionsPage"; //$NON-NLS-1$

    private static String DATABASE_AUTHENTICATION_WIZARD_PAGE_NAME = "com.ibm.datatools.modeler.fe.ui.wizards.DatabaseAuthenticationPage"; //$NON-NLS-1$

    private static String CONFIGURE_JDBC_WIZARD_PAGE_NAME = "com.ibm.datatools.modeler.fe.ui.wizards.ConfigureJDBCPage"; //$NON-NLS-1$

    private static String SUMMARY_WIZARD_PAGE_NAME = "com.ibm.datatools.modeler.fe.ui.wizards.SummaryPage"; //$NON-NLS-1$

    private List selection;

    private DDLGenerator feProvider;

    private DatabaseDefinition databaseDefinition;

    String lastProductValueSet = ""; //$NON-NLS-1$

    String lastVersionValueSet = ""; //$NON-NLS-1$

    private Connection connection = null;

    private ConnectionInfo connectionInfo = null;

    private StringWriter writer = new StringWriter();

    private String[] ddlScripts = new String[0];

    private boolean hasGenerated = false;
       
    private static String LINE_RETURN = System.getProperty("line.separator");

    public FEWizard(List selection) {
        super();
        this.selection = selection;
        this.setWindowTitle(ResourceLoader.INSTANCE
                .queryString("FE_WIZARD_TITLEBAR_TEXT")); //$NON-NLS-1$
        this.setDefaultPageImageDescriptor(ImageDescription
                .getGenerateDDLWizard());
        setNeedsProgressMonitor(true);
    }

    public void addPages() {

        Database database = this.getDatabase((SQLObject) selection.get(0));
        databaseDefinition = RDBCorePlugin.getDefault()
                .getDatabaseDefinitionRegistry().getDefinition(
                        database.getVendor(), database.getVersion());
        this.feProvider = databaseDefinition.getDDLGenerator();
        FEConfigurationData configurationData = new FEConfigurationData(
                this.feProvider.getOptions(
                        (SQLObject[]) selection.toArray(new SQLObject[selection.size()]))); //@d00058820gs

        selectOptionsPage = new FESelectOptionsWizardPage(
                SELECT_OPTIONS_WIZARD_PAGE_NAME, configurationData);
        addPage(selectOptionsPage);

        selectObjectsPage = new FESelectObjectsWizardPage(
        		SELECT_OBJECTS_WIZARD_PAGE_NAME, configurationData);
        addPage(selectObjectsPage);
        
        selectFilePage = new FESelectFileWizardPage(
                SELECT_FILE_WIZARD_PAGE_NAME, this.selection);
        addPage(selectFilePage);
        selectFilePage.setTerminator(databaseDefinition.getSQLTerminationCharacter());

        existingConnectionsPage = new FESpecifyExistingConnectionsWizardPage(
                EXISTING_CONNECTIONS_WIZARD_PAGE_NAME);
        addPage(existingConnectionsPage);

        databaseAuthenticationPage = new DatabaseAuthenticationWizardPage(
                DATABASE_AUTHENTICATION_WIZARD_PAGE_NAME);
        addPage(databaseAuthenticationPage);

        configureJDBCPage = new FEConfigureJDBCConnectionWizardPage(
                CONFIGURE_JDBC_WIZARD_PAGE_NAME);
        addPage(configureJDBCPage);

        summaryPage = new FESummaryWizardPage(SUMMARY_WIZARD_PAGE_NAME);
        addPage(summaryPage);
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.eclipse.jface.wizard.Wizard#performFinish()
     */
    public boolean performFinish() {
        WorkspaceModifyOperation operation = new WorkspaceModifyOperation() {
            protected void execute(IProgressMonitor monitor) {
                try {
                    performDDLGeneration(monitor);
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                } finally {
                    monitor.done();
                }
            }
        };

        try {
            getContainer().run(false, false, operation);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    public StringWriter generateDDL() {
        try {
            getContainer().run(false, false, new IRunnableWithProgress() {
                public void run(IProgressMonitor monitor)
                        throws InvocationTargetException, InterruptedException {
                    writer = new StringWriter();
                    monitor.beginTask("", 5); //$NON-NLS-1$
                    monitor
                            .setTaskName(ResourceLoader.INSTANCE
                                    .queryString("FEWizard.generatingDDLProgressMessage")); //$NON-NLS-1$
                    monitor.worked(1);
                    hasGenerated = false;
                    FEConfigurationData configurationData = selectOptionsPage
                            .getOptions();
                    if (configurationData != null) {
                        try {
                        	String fullStatementTermination = "";
                        	String statementTerminator = selectFilePage.getTerminator();
                        	if (statementTerminator.length() < 2){
                        		fullStatementTermination += statementTerminator + LINE_RETURN + LINE_RETURN;
                        	} else {
                        		fullStatementTermination += LINE_RETURN + statementTerminator + LINE_RETURN + LINE_RETURN;
                        	}
                            ddlScripts = feProvider.generateDDL(
                                    (SQLObject[]) selection
                                            .toArray(new SQLObject[selection
                                                    .size()]), monitor);
                            hasGenerated = true;
                            monitor.worked(3);

                            for (int i = 0; i < ddlScripts.length; i++) {
                                writer
                                        .write(ddlScripts[i]
                                                + fullStatementTermination);													  
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

        return this.writer;
    }

    public void performDDLGeneration(IProgressMonitor monitor) {

        try {
            if (hasGenerated) {
                monitor.worked(2);
                monitor.setTaskName(ResourceLoader.INSTANCE
                        .queryString("FEWizard.savingDDLProgressMessage")); //$NON-NLS-1$               
                IFile ddlFile = SaveDDLUtility.getInstance()
                        .saveDDLFileAsResource(this.writer,
                                selectFilePage.getResourcePath());              
                monitor.worked(4);
                if (selectFilePage.isOpenDDLSelected()) {
                    monitor.setTaskName(ResourceLoader.INSTANCE
                            .queryString("FEWizard.openingDDLProgressMessage")); //$NON-NLS-1$
                    if (ddlFile != null) {
//                        IEditorDescriptor editorDescriptor = PlatformUI
//                                .getWorkbench().getEditorRegistry()
//                                .getDefaultEditor(ddlFile.getName());
//                        if (editorDescriptor == null) {
//                            editorDescriptor = PlatformUI.getWorkbench()
//                                    .getEditorRegistry().getDefaultEditor(
//                                            "file.txt"); //$NON-NLS-1$
//                        }
//                        PlatformUI.getWorkbench().getActiveWorkbenchWindow()
//                                .getActivePage().openEditor(
//                                        new FileEditorInput(ddlFile),
//                                        editorDescriptor.getId());
                        SQLEditorFileEditorInput editorInput = new SQLEditorFileEditorInput(ddlFile);
                        Object selectedObj = selection.get(0);
                        if (selectedObj instanceof SQLObject) {
                            SQLObject sqlObj = (SQLObject) selectedObj;
                            Database database = getDatabase(sqlObj);
                            if (database != null) {
                                ConnectionManager connMgr = RDBCorePlugin.getDefault().getConnectionManager();
                                if (connMgr != null) {
                                    ConnectionInfo connInfo = connMgr.getConnectionInfo(database);
                                    editorInput.setConnectionInfo(connInfo);
                                }
                            }
                        }
                        
                        PlatformUI.getWorkbench().getActiveWorkbenchWindow()
                                .getActivePage().openEditor(editorInput,
                                 "org.eclipse.wst.rdb.sqleditor.SQLEditor"); //$NON-NLS-1$
                    }
                }

                if (selectFilePage.isExecuteSelected()) {
                    Connection conn = getDBConnection();
                    if (conn != null && ddlScripts != null) {
                        for (int index = 0; index < ddlScripts.length; index++) {
                            monitor
                                    .setTaskName(ResourceLoader.INSTANCE
                                            .queryString("FEWizard.executingProgressMessage") + ddlScripts[index]); //$NON-NLS-1$
                            new QueryOutputHelper(ddlScripts[index], conn)
                                    .executeDDL(ResourceLoader.INSTANCE
                                            .queryString("FEWizard.queryOutputSourceIdentity")); //$NON-NLS-1$
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (!hasGenerated) {
                MessageBox box = new MessageBox(Display.getCurrent()
                        .getActiveShell(), SWT.ABORT | SWT.ICON_ERROR);
                box.setMessage(ResourceLoader.INSTANCE
                        .queryString("FEWizard.ddlGenerationErrorMessage")); //$NON-NLS-1$
                box.open();
            }
        }
        monitor.worked(5);
    }

    public boolean canFinish() {
        boolean canFinish = false;
        if (!selectFilePage.isExecuteSelected()) {
            canFinish = selectOptionsPage.isPageComplete() 
					&& selectObjectsPage.isPageComplete()
                    && selectFilePage.isPageComplete()
            		&& summaryPage.isVisible();
        } else {
            if (existingConnectionsPage.isNewConnectionSelected()) {
                canFinish = selectOptionsPage.isPageComplete()
						&& selectObjectsPage.isPageComplete()
                        && selectFilePage.isPageComplete()
                        && configureJDBCPage.isPageComplete()
                        && summaryPage.isVisible();
            } else {
                canFinish = selectOptionsPage.isPageComplete()
						&& selectObjectsPage.isPageComplete()
                        && selectFilePage.isPageComplete()
                        && summaryPage.isVisible();
            }
        }
        return canFinish;

    }

    public IWizardPage getNextPage(IWizardPage wizardPage) {
        IWizardPage nextPage = null;

        databaseAuthenticationPage.setConnectionInfo(existingConnectionsPage
                .getSelectedConnection());

        String currentProductSet = databaseDefinition.getProduct();
        String currentVersionSet = databaseDefinition.getVersion();

        if ((!lastProductValueSet.equals(currentProductSet))
                || ((!lastVersionValueSet.equals(currentVersionSet)))) {
            lastProductValueSet = currentProductSet;
            lastVersionValueSet = currentVersionSet;
            existingConnectionsPage.setAllowedProduct(currentProductSet);
            existingConnectionsPage.setAllowedVersion(currentVersionSet);
            configureJDBCPage
                    .setAllowedProductVersions(new DatabaseProductVersion[] { new DatabaseProductVersion(
                            currentProductSet, currentVersionSet) });
        }

        if (wizardPage.getName().equals(SELECT_OPTIONS_WIZARD_PAGE_NAME)) {
            nextPage = selectObjectsPage;
            
        } else   if (wizardPage.getName().equals(SELECT_OBJECTS_WIZARD_PAGE_NAME)) {
                nextPage = selectFilePage;
            
        } else if (wizardPage.getName().equals(SELECT_FILE_WIZARD_PAGE_NAME)) {
            if (selectFilePage.isExecuteSelected()) {
                nextPage = existingConnectionsPage;
            } else {
                nextPage = populateSummaryPage(); //@d00058820gs
            }
        } else if (wizardPage.getName().equals(
                EXISTING_CONNECTIONS_WIZARD_PAGE_NAME)) {
            if (existingConnectionsPage.isNewConnectionSelected()) {
                nextPage = configureJDBCPage;
            } else {
                // determine if prompt is needed
                if (existingConnectionsPage.isSelectedConnectionClosed()) {
                    nextPage = databaseAuthenticationPage;
                } else {
                    nextPage = populateSummaryPage(); //@d00058820gs
                }
            }
        } else if (wizardPage.getName().equals(
                DATABASE_AUTHENTICATION_WIZARD_PAGE_NAME)) {
            nextPage = populateSummaryPage(); //@d00058820gs
        } else if (wizardPage.getName().equals(CONFIGURE_JDBC_WIZARD_PAGE_NAME)) {
            nextPage = populateSummaryPage(); //@d00058820gs
        } else if (wizardPage.getName().equals(SUMMARY_WIZARD_PAGE_NAME)) {
            nextPage = null;
        } else {
            nextPage = super.getNextPage(wizardPage);
        }
        return nextPage;
    }

    //@d00058820gs: performance improvement
    //Populate Summary Page
    private FESummaryWizardPage populateSummaryPage() 
    {
        if (summaryPage == null) {
        	summaryPage = new FESummaryWizardPage(SUMMARY_WIZARD_PAGE_NAME);
        	addPage(summaryPage);
        }
        // Populate summary page
        EngineeringOption[] options = selectOptionsPage.getOptions()
                .getOptions();
        FESummaryProperty[] properties = null;
        Vector propertiesCollection = new Vector();
        propertiesCollection
                .add(new FESummaryProperty(
                        ResourceLoader.INSTANCE
                                .queryString("FEWizard.fileLocationSummaryProperty"), selectFilePage.getResourcePath())); //$NON-NLS-1$
        propertiesCollection
                .add(new FESummaryProperty(
                        ResourceLoader.INSTANCE
                                .queryString("FEWizard.openDDLForEditingSummaryProperty"), String.valueOf(selectFilePage.isOpenDDLSelected()))); //$NON-NLS-1$     
        propertiesCollection.add(new FESummaryProperty("", "")); //$NON-NLS-1$ //$NON-NLS-2$
        
        // Add generation options
        for (int index = 0; index < options.length; index++) {
            propertiesCollection.add(new FESummaryProperty(options[index]
                    .getOptionDescription(), String.valueOf(options[index]
                    .getBoolean())));
        }
        propertiesCollection.add(new FESummaryProperty("", "")); //$NON-NLS-1$ //$NON-NLS-2$
        
        // Add object selection options
        options = selectObjectsPage.getOptions().getOptions();      
        for (int index = 0; index < options.length; index++) {
            propertiesCollection.add(new FESummaryProperty(options[index]
                    .getOptionDescription(), String.valueOf(options[index]
                    .getBoolean())));
        }
              
        properties = new FESummaryProperty[propertiesCollection.size()];
        propertiesCollection.toArray(properties);
        summaryPage.setProperties(properties);
        
        return summaryPage;
    }

    private Connection getDBConnection() {
        Connection connection = null;
        try {
            if (this.connection != null) {
                connection = this.connection;
            } else {

                if (existingConnectionsPage.isNewConnectionSelected()) {
                    ConnectionInfo connectionInfo = null;
                    configureJDBCPage.internalSaveWidgetValues();
                    configureJDBCPage.performTestConnection(false);
                    if (configureJDBCPage.isFinalConnection()) {
                        connectionInfo = configureJDBCPage.getConnection();
                        connection = persistConnection(connectionInfo);
                        this.connection = connection;
                        this.connectionInfo = connectionInfo;

                    }
                } else {
                    this.connectionInfo = existingConnectionsPage
                            .getSelectedConnection();
                    this.connection = this.connectionInfo.getSharedConnection();
                    connection = this.connection;
                }
            }
            return connection;

        } catch (Exception e) {
            // If the connection is not valid, then this method should return
            // null
        }

        return null;
    }

    public Connection persistConnection(ConnectionInfo connectionInfo) {
        Connection connection = null;
        try {
            connection = connectionInfo.connect();
            connectionInfo.setSharedConnection(connection);
            connectionInfo.saveConnectionInfo();
            new DatabaseProviderHelper().setDatabase(connection,
                    connectionInfo, connectionInfo.getDatabaseName());
        } catch (Exception e) {
            RDBCorePlugin.getDefault().getConnectionManager()
                    .removeConnectionInfo(connectionInfo.getName());
            connection = null;
        }
        return connection;
    }
    
	private Database getDatabase (EObject object)
	{
		if (object == null)
		{
			return null;
		}
		else if (object instanceof Database)
		{
			return (Database) object;
		}
		else
		{
			return getDatabase (RDBCorePlugin.getDefault().getContainmentService().getContainer(object));
		}
	}
}