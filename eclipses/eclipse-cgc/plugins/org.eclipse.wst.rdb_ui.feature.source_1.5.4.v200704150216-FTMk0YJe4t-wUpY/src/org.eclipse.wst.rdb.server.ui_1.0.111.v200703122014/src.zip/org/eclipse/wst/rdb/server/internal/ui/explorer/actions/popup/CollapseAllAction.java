/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.server.internal.ui.explorer.actions.popup;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.wst.rdb.server.internal.ui.services.IServicesManager;


/**
 * @author ljulien
 */
public class CollapseAllAction extends AbstractAction
{
    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.explorer.actions.popup.AbstractAction#setSelection(org.eclipse.jface.viewers.ISelection)
     */
    protected void setSelection(ISelection selection)
    {
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.explorer.actions.popup.AbstractAction#getSelection()
     */
    protected ISelection getSelection()
    {
        return null;
    }

    /**
     * @see org.eclipse.ui.IActionDelegate#run(org.eclipse.jface.action.IAction)
     */
    public void run(IAction action)
    {
        IServicesManager.INSTANCE.getServerExplorerContentService().collapseAll();
    }
}
