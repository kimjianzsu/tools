/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others. All rights reserved.
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: IBM Corporation - initial API and implementation
 ******************************************************************************/

package org.eclipse.wst.rdb.server.internal.ui.wizards;

import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.wst.rdb.connection.internal.ui.filter.SchemaFilterWizardPage;
import org.eclipse.wst.rdb.connection.internal.ui.util.resource.ResourceLoader;

/**
 * @author ledunnel
*/
public class NewConnectionSchemaFilterWizardPage extends SchemaFilterWizardPage{

    /**
     * @param pageName
     */
    public NewConnectionSchemaFilterWizardPage(String pageName) {
        super(pageName);
        setTitle(ResourceLoader.INSTANCE.queryString("_UI_TITLE_FILTER"));      //$NON-NLS-1$
    }
    public IWizardPage getPreviousPage() {
        return null;
    }
    public void createControl(Composite composite){
        super.createControl(composite);
        this.setPageComplete(true);
    }
    
    public void setVisible(boolean visible){
        if  (visible){
           setConnectionInfo(((NewConnectionWizard) getWizard()).getDBConnection(false)); 
        this.setPageComplete(validatePage());
        }
        super.setVisible(visible);   
    }
}
