/*
 *+------------------------------------------------------------------------------------------------+
 *|  IBM Confidential																			   |
 *|  OCO Source Materials																		   |
 *|  5724-L66																					   |
 *|  (c) Copyright IBM Corp.  2005 All Rights Reserved											   |
 *|  The source code for this program is not published or otherwise divested of its trade secrets, |
 *|  irrespective of what has been deposited with the U.S. Copyright Office.					   |
 *+------------------------------------------------------------------------------------------------+
 */
package org.eclipse.wst.rdb.server.internal.ui.explorer.actions.popup;

import org.eclipse.jface.action.IMenuManager;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.CommonActionProvider;
import org.eclipse.ui.navigator.ICommonActionExtensionSite;
import org.eclipse.ui.navigator.ICommonMenuConstants;

/**
 * @author ljulien
 */
public class NavigatorRefresh extends CommonActionProvider
{
    private RefreshAction refreshAction = new RefreshAction();
    
    public void init(ICommonActionExtensionSite aConfig)
    {
    }
    
    public void fillContextMenu(IMenuManager aMenu)
    {
    	if (getContext() != null)
    	{
    		refreshAction.selectionChanged(null, getContext().getSelection());
    		aMenu.insertAfter(ICommonMenuConstants.GROUP_REORGANIZE, refreshAction);
    	}
    }

    public void dispose()
    {
    }

    public void fillActionBars(IActionBars theActionBars)
    {
    }

    public void restoreState(IMemento aMemento)
    {
    }

    public void saveState(IMemento aMemento)
    {
    }
}
