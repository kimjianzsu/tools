/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.rdb.server.internal.ui.explorer.providers.content.impl;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonContentProvider;
import org.eclipse.wst.rdb.core.internal.ui.explorer.providers.content.virtual.VirtualNode;
import org.eclipse.wst.rdb.core.internal.ui.explorer.services.IVirtualNodeServiceFactory;
import org.eclipse.wst.rdb.core.internal.ui.explorer.virtual.IConnectionNode;
import org.eclipse.wst.rdb.core.internal.ui.explorer.virtual.IKnownConnectionNode;
import org.eclipse.wst.rdb.core.internal.ui.explorer.virtual.IVirtualNode;
import org.eclipse.wst.rdb.core.internal.ui.services.IDataToolsUIServiceManager;
import org.eclipse.wst.rdb.internal.core.RDBCorePlugin;
import org.eclipse.wst.rdb.internal.core.connection.ConnectionInfo;
import org.eclipse.wst.rdb.internal.core.connection.ConnectionManager;
import org.eclipse.wst.rdb.internal.core.containment.ContainmentService;
import org.eclipse.wst.rdb.server.internal.ui.explorer.ServerExplorerViewer;
import org.eclipse.wst.rdb.server.internal.ui.explorer.content.ConnectionNodeUtil;
import org.eclipse.wst.rdb.server.internal.ui.explorer.content.ServerExplorerConfiguration;
import org.eclipse.wst.rdb.server.internal.ui.explorer.content.ServerExplorerInitializer;
import org.eclipse.wst.rdb.server.internal.ui.explorer.providers.ServerExplorerManager;
import org.eclipse.wst.rdb.server.internal.ui.explorer.providers.content.layout.IServerExplorerLayoutProviderNav;
import org.eclipse.wst.rdb.server.internal.ui.explorer.providers.content.layout.hierar.ServerExplorerHierarchicalLayoutNav;
import org.eclipse.wst.rdb.server.internal.ui.explorer.providers.content.layout.vnode.ServerExplorerVirtualNodeLayoutNav;
import org.eclipse.wst.rdb.server.internal.ui.layout.IServerExplorerLayoutExtensionProvider;
import org.eclipse.wst.rdb.server.internal.ui.layout.IServerExplorerLayoutExtensionProvider.Layout;
import org.eclipse.wst.rdb.server.internal.ui.services.IServerExplorerContentService;
import org.eclipse.wst.rdb.server.internal.ui.services.IServerExplorerLayoutService;
import org.eclipse.wst.rdb.server.internal.ui.services.IServerExplorerNavigationService;
import org.eclipse.wst.rdb.server.internal.ui.util.TransientEObjectUtil;
import org.eclipse.wst.rdb.server.internal.ui.util.TransientEObjectUtil.IGroup;
import org.eclipse.wst.rdb.server.internal.ui.util.resources.ResourceLoader;


/**
 * @author ljulien
 */
public class ServerExplorerContentProviderNav implements ICommonContentProvider, IServerExplorerContentService,
        IServerExplorerLayoutService, IServerExplorerNavigationService
{
    private static final ContainmentService containmentService = RDBCorePlugin.getDefault().getContainmentService();
    private static final ConnectionManager manager = RDBCorePlugin.getDefault().getConnectionManager();
    
    private static final ResourceLoader resourceLoader = ResourceLoader.INSTANCE;

    private static final Object[] EMPTY_ELEMENT_ARRAY = new Object[0];
    private static final String KNOWN_SERVERS = resourceLoader.queryString("DATATOOLS.SERVER.UI.EXPLORER.KNOWN_SERVERS"); //$NON-NLS-1$

    private static final IVirtualNodeServiceFactory virtualNodeFactory = IDataToolsUIServiceManager.INSTANCE.getVirtualNodeServiceFactory();
    
    private ServerExplorerViewer databaseExplorerViewer;
    private ServerExplorerConfiguration serverExplorerConfiguration = new ServerExplorerConfiguration();
    private IKnownConnectionNode knownServer;
    private IServerExplorerLayoutProviderNav layoutProvider;
    private List layoutProvidersExtensionList = new LinkedList();
    
    /**
     * Will initialize the Server Explorer
     */
    private void initializeServerExplorer()
    {
        knownServer = virtualNodeFactory.makeKnownConnectionNode(KNOWN_SERVERS, KNOWN_SERVERS, null);
        ServerExplorerManager.INSTANCE.setRootKnownServerNode(knownServer);

        ServerExplorerManager.INSTANCE.setServerExplorerService(this);
    }

    /**
     * Will initialize the Layout Extension providers that are connected to the Server Explorer
     */
    private void initializeLayoutExtensionProviders()
    {
        IExtensionRegistry pluginRegistry = Platform.getExtensionRegistry();
        IExtensionPoint extensionPoint = pluginRegistry.getExtensionPoint("org.eclipse.wst.rdb.server.ui", //$NON-NLS-1$
                "serverExplorerLayoutExtension"); //$NON-NLS-1$ //$NON-NLS-2$
        IExtension[] extensions = extensionPoint.getExtensions();
        for (int i = 0; i < extensions.length; ++i)
        {
            IConfigurationElement[] configElements = extensions[i].getConfigurationElements();
            for (int j = 0; j < configElements.length; ++j)
            {
                try
                {
                    IServerExplorerLayoutExtensionProvider layout = (IServerExplorerLayoutExtensionProvider) configElements[j]
                            .createExecutableExtension("class"); //$NON-NLS-1$
                    layout.enableLayout(isVirtualNodeLayoutSelected() ? Layout.VNODE : Layout.HIERARCHICAL);
                    layoutProvidersExtensionList.add(layout);
                }
                catch (CoreException e)
                {
                }
            }
        }
    }
    
    /**
     * Will disconnect the Server
     * @param server
     */
    private void removeServerConnection(IConnectionNode server)
    {
        server.shouldDisconnect(true);
    }

    /**
     * @param connected - if we want the connected [true] / disconnected [false] servers
     * @return the array of asked servers
     */
    private IConnectionNode[] getServers(boolean connected)
    {
        List connectedServers = new LinkedList();
        for (int i = 0, n = knownServer.getChildrenArray().length; i < n; i++)
        {
            IConnectionNode server = (IConnectionNode) knownServer.getChildrenArray()[i];
            if (server.isConnected() == connected)
            {
                connectedServers.add(server);
            }
        }
        return (IConnectionNode[]) connectedServers.toArray(new IConnectionNode[connectedServers.size()]);
    }
    
    private Object getConnectionNode (Object element)
    {
        Object [] nodes = getKnownServerNode().getChildrenArray();
        for (int i = 0, n = nodes.length; i < n; i++)
        {
            Object current = nodes[i];
            if (current instanceof IConnectionNode)
            {
                IConnectionNode node = (IConnectionNode)current;
                if (Arrays.asList(node.getChildrenArray()).contains(element))
                {
                    return node;
                }
            }
        }
        return null;
    }
    
    /**
     * @return The viewer used by the Server Explorer
     */
    private ServerExplorerViewer getViewer ()
    {
        return this.databaseExplorerViewer;
    }

    /**
     * @see org.eclipse.ui.views.navigator.INavigatorContentProvider#inputChanged(org.eclipse.jface.viewers.Viewer, java.lang.Object, java.lang.Object)
     */
    public void inputChanged(Viewer viewer, Object oldInput, Object newInput)
    {
        if (newInput != null)
        {
            this.databaseExplorerViewer = (ServerExplorerViewer) viewer;
            new ServerExplorerInitializer().loadLocalRegisteredDatabases();
            layoutProvider.initializeKnownServers(knownServer);
        }
    }

    /**
     * @see org.eclipse.jface.viewers.ITreeContentProvider#getChildren(java.lang.Object)
     */
    public Object[] getChildren(Object parentElement)
    {
        if (parentElement instanceof IWorkspaceRoot)
        {
            return new Object[] { knownServer };
        }
        else
        {
            if (parentElement instanceof IConnectionNode && ((IConnectionNode) parentElement).shouldDisconnect())
            {
                ((IConnectionNode) parentElement).setConnected(false);
                return EMPTY_ELEMENT_ARRAY;
            }
            else if (parentElement instanceof VirtualNode && ((IVirtualNode) parentElement).hasChildren())
            {
                return ((IVirtualNode) parentElement).getChildrenArray();
            }
            else
            {
                return layoutProvider.getChildren(parentElement);
            }
        }
    }

    /**
     * @see org.eclipse.jface.viewers.ITreeContentProvider#getParent(java.lang.Object)
     */
    public Object getParent(Object element)
    {
        if (element instanceof IWorkspaceRoot)
        {
            return knownServer;
        }
        else
        {
            Object result = getViewer().getParent(element);
            result = result != null ? result : element instanceof IVirtualNode ? ((IVirtualNode) element).getParent() : null;
            result = result != null || !(element instanceof EObject) ? result : containmentService
                    .getContainer((EObject) element);
            return result == null && element instanceof EObject && containmentService.getContainer((EObject) element) == null ? getConnectionNode(element) : result;
        }
    }

    /**
     * @see org.eclipse.jface.viewers.ITreeContentProvider#hasChildren(java.lang.Object)
     */
    public boolean hasChildren(Object element)
    {
        return element instanceof IConnectionNode && ((IConnectionNode)element).getConnectionInfo().getSharedDatabase() == null ? false : true;
    }

    /**
     * @see org.eclipse.jface.viewers.IStructuredContentProvider#getElements(java.lang.Object)
     */
    public Object[] getElements(Object inputElement)
    {
        return getChildren(inputElement);
    }

    /**
     * @see org.eclipse.jface.viewers.IContentProvider#dispose()
     */
    public void dispose()
    {
        ServerExplorerManager.INSTANCE.setServerExplorerService(null);
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#addNode(java.lang.Object)
     */
    public void addNode(Object newNode)
    {
        addNode(ResourcesPlugin.getWorkspace().getRoot(), newNode);
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#addNode(java.lang.Object, java.lang.Object)
     */
    public void addNode(Object parentNode, Object newNode)
    {
        if (parentNode instanceof IVirtualNode)
        {
            ((IVirtualNode) parentNode).addChildren(newNode);
        }
        getViewer().add(parentNode, newNode);
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#addKnownServer(java.lang.Object)
     */
    public void addKnownServer(Object server)
    {
        IConnectionNode serverNode = (IConnectionNode) server;
        serverNode.setConnected(true);
        knownServer.addChildren(serverNode);
        getViewer().add(getKnownServerNode(), serverNode);
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#addProxyNode(java.lang.Object)
     */
    public void addProxyNode(Object parentNode)
    {
    }

    private void loadChilds (ServerExplorerViewer viewer, Object parent)
    {
        viewer.expandToLevel(parent, 1);
    }
    
    private Object getVirtualNode (ServerExplorerViewer viewer, Object parent, String groupID)
    {
        if (parent != null)
        {
	        if (parent instanceof IConnectionNode)
	        {
	            return parent;
	        }
	        else
	        {
	            TreeItem [] items = viewer.getServerExplorerChildren(parent);
	            if (items.length != 0)
	            {	
	                for (int i = 0, n = items.length; i < n; i++)
	                {
	                    TreeItem child = items[i];
	                    Object childNode = child.getData ();
	                    if (childNode instanceof IVirtualNode && ((IVirtualNode)childNode).getGroupID().equals(groupID))
	                    {
	                        return (IVirtualNode) child.getData();
	                    }
	                }
	            }
	        }
        }
        return null;
    }
    
    private Object getEObjectNode (ServerExplorerViewer viewer, Object parent, String name)
    {
        if (parent != null)
        {
	        TreeItem [] items = viewer.getServerExplorerChildren(parent);
	        if (items.length != 0)
	        {
	            for (int i = 0, n = items.length; i < n; i++)
	            {
	                TreeItem child = items[i];
	                Object childNode = child.getData ();
	                if (childNode instanceof ENamedElement && ((ENamedElement)childNode).getName().equals (name))
	                {
	                    return childNode;
	                }
	            }
	        }
        }
        return null;
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.services.IServerExplorerContentService#expandNode(java.lang.String)
     */
    public void expandNode (String pathToNavigate)
    {
        final ServerExplorerViewer viewer = getViewer();

        try
        {
            List path = TransientEObjectUtil.getPathFromID (pathToNavigate);
            Iterator pathIterator = path.iterator();
            
            Object parent1 = ConnectionNodeUtil.getConnectionNode(manager.getConnectionInfo((String)pathIterator.next()));
            Object parent2 = null;
            while (pathIterator.hasNext())
            {
                String pathString = (String) pathIterator.next();
                IGroup group = TransientEObjectUtil.getGroupInfo(pathString);
                String groupID = group.getGroupId();
                String elementName = group.getElementName();
                
                parent2 = getVirtualNode (viewer, parent1, groupID);
                if (parent2 == null)
                {
    	            loadChilds (viewer, parent1);
    	            parent2 = getVirtualNode (viewer, parent1, groupID);
    	            if (parent2 == null && parent1 instanceof IVirtualNode)
    	            {
    	                Object [] children =  ((IVirtualNode) parent1).getChildrenArray();
    	                for (int i = 0, n = children.length; i < n; i++)
    	                {
    	                    Object parent4 = getVirtualNode (viewer, children[i], groupID);
    	                    if (parent4 != null)
    	                    {
    	                        parent2 = parent4;
    	                        break;
    	                    }
    	                }
    	            }
                }
                else
                {
    	            loadChilds (viewer, parent2);
    	            Object parent3 = getVirtualNode (viewer, parent2, groupID);
    	            if (parent3 != null)
    	            {
    	                parent2 = parent3;
    	            }
                }
                parent1 = parent2;
                if (elementName != null)
                {
                    parent2 = getEObjectNode (viewer, parent1, elementName);
	                if (parent2 == null)
	                {
	        	        loadChilds (viewer, parent1);
	        	        parent2 = getEObjectNode (viewer, parent1, elementName);
	                }
                }
                parent1 = parent2;
            }
            
            viewer.selectInExplorer(new StructuredSelection(parent1));
        }
        catch (Exception e)
        {
        }
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#expandNode(java.lang.Object)
     */
    public void expandNode(EObject eObject)
    {
        try
        {
            expandNode (TransientEObjectUtil.getEObjectId(eObject));
        }
        catch (Exception e)
        {
        }
    }

    public void selectAndReveal(ISelection selection)
    {
        if (selection instanceof IStructuredSelection)
        {
            IStructuredSelection structuredSelection = (IStructuredSelection) selection;
            for (Iterator iterator = structuredSelection.iterator(); iterator.hasNext();)
            {
                Object object = iterator.next();
                if (object instanceof EObject)
                {
                    expandNode ((EObject)object);
                }
            }
        }
        getViewer().setSelection(selection, true);
    }

    public void updateSelection (ISelection selection)
    {
        getViewer().updateExplorerSelection(selection);
    }
    
    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#getServerExplorerLayoutServices()
     */
    public IServerExplorerLayoutService getServerExplorerLayoutService()
    {
        return this;
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#refreshServerExplorer()
     */
    public void refreshServerExplorer()
    {
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#updateLayout()
     */
    public void updateLayout()
    {
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#refreshNode(java.lang.Object)
     */
    public void refreshNode(Object node)
    {
        getViewer().refresh(node, true);
    }

    /**
     * Expand that node to the depth provided
     */
    public void expandNode (Object node, int depth)
    {
        while (Display.getDefault().readAndDispatch());
        getViewer().expandToLevel(node, depth);
    }
    
    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#collapseAll()
     */
    public void collapseAll()
    {
        getViewer().collapseAll();
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#getAllConnectedServers()
     */
    public IConnectionNode[] getAllConnectedServers()
    {
        return getServers(true);
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#getAllDisconnectedServers()
     */
    public IConnectionNode[] getAllDisconnectedServers()
    {
        return getServers(false);
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#disconnectServers(com.ibm.datatools.core.ui.modelexplorer.virtual.IServerNode[])
     */
    public void disconnectServers(IConnectionNode[] servers)
    {
        for (int i = 0, n = servers.length; i < n; i++)
        {
            removeServerConnection(servers[i]);
            getViewer().refresh(servers[i], true);
        }
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#connectServer(java.lang.Object)
     */
    public void connectServer(Object server)
    {
        IConnectionNode serverNode = (IConnectionNode) server;
        getViewer().refresh(serverNode, true);
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerLayoutServices#enableVirtualNodeLayout()
     */
    public void enableVirtualNodeLayout()
    {
        this.layoutProvider = new ServerExplorerVirtualNodeLayoutNav(this);
        for (Iterator iterator = layoutProvidersExtensionList.iterator(); iterator.hasNext();)
        {
            ((IServerExplorerLayoutExtensionProvider) iterator.next()).enableLayout(Layout.VNODE);
        }
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerLayoutServices#enableHierarchicalLayout()
     */
    public void enableHierarchicalLayout()
    {
        this.layoutProvider = new ServerExplorerHierarchicalLayoutNav(this);
        for (Iterator iterator = layoutProvidersExtensionList.iterator(); iterator.hasNext();)
        {
            ((IServerExplorerLayoutExtensionProvider) iterator.next()).enableLayout(Layout.HIERARCHICAL);
        }
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerLayoutServices#isVirtualNodeLayoutSelected()
     */
    public boolean isVirtualNodeLayoutSelected()
    {
        return this.layoutProvider instanceof ServerExplorerVirtualNodeLayoutNav;
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerLayoutServices#isHierarchicalLayoutSelected()
     */
    public boolean isHierarchicalLayoutSelected()
    {
        return this.layoutProvider instanceof ServerExplorerHierarchicalLayoutNav;
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#getKnownServerNode()
     */
    public IKnownConnectionNode getKnownServerNode()
    {
        return knownServer;
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#deleteServer(com.ibm.datatools.core.ui.modelexplorer.virtual.IServerNode[])
     */
    public void deleteServer(IConnectionNode[] servers)
    {
        for (int i = 0, n = servers.length; i < n; i++)
        {
            serverExplorerConfiguration.deleteServer(servers[i]);
            removeServerConnection(servers[i]);
            getKnownServerNode().removeChildren(servers[i]);
            getViewer().remove(servers[i]);
        }
    }

    /**
     * @see org.eclipse.wst.rdb.server.internal.ui.ui.services.IServerExplorerServices#reconnectServer(com.ibm.datatools.core.ui.modelexplorer.virtual.IServerNode[])
     */
    public void reconnectServer(IConnectionNode[] servers)
    {
    }

    public void removeNode(Object parent, Object removedChild)
    {
        getViewer().remove(removedChild);
    }

    public Object[] getServerExplorerObjectsByType(ConnectionInfo info, Class type)
    {
        return getViewer().getServerExplorerObjectsByType(info, type);
    }

    public Object[] getServerExplorerObjectsByType(Object parent, Class type)
    {
        return getViewer().getServerExplorerObjectsByType(parent, type);
    }

    public void init(ICommonContentExtensionSite aConfig)
    {
        this.enableVirtualNodeLayout();
        initializeServerExplorer();
        initializeLayoutExtensionProviders();
    }

    public void restoreState(IMemento aMemento)
    {
    }

    public void saveState(IMemento aMemento)
    {
    }
}
