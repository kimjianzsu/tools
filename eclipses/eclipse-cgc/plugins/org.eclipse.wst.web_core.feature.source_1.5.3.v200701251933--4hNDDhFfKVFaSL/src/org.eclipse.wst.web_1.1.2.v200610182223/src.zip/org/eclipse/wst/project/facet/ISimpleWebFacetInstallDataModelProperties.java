package org.eclipse.wst.project.facet;

public interface ISimpleWebFacetInstallDataModelProperties {

	public static final String CONTENT_DIR = "IStaticWebFacetInstallDataModelProperties.CONTENT_DIR"; //$NON-NLS-1$
	
	public static final String CONTEXT_ROOT = "IStaticWebFacetInstallDataModelProperties.CONTEXT_ROOT"; //$NON-NLS-1$
}
