package org.eclipse.wst.web.internal.operation;



public interface IWebProjectPropertiesUpdateDataModelProperties {

	public static final String PROJECT = "IWebProjectPropertiesUpdateDataModelProperties.PROJECT"; //$NON-NLS-1$	
	public static final String CONTEXT_ROOT = "IWebProjectPropertiesUpdateDataModelProperties.CONTEXT_ROOT"; //$NON-NLS-1$

}
