/*******************************************************************************
 * Copyright (c) 2003, 2005 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - Initial API and implementation
 *******************************************************************************/
package org.eclipse.wst.server.ui.internal.wizard.fragment;

import org.eclipse.wst.server.ui.wizard.WizardFragment;
/**
 * 
 */
public class ServerConfigurationWizardFragment extends WizardFragment {
	public ServerConfigurationWizardFragment() {
		// do nothing
	}
	
	public void enter() {
		//TaskModel model = getTaskModel();
		//IRuntime runtime = (IRuntime) model.getObject(TaskModel.TASK_RUNTIME);
		//IServerWorkingCopy server = (IServerWorkingCopy) model.getObject(TaskModel.TASK_SERVER);
		
		//IServerType type = server.getServerType();
		/*if (type.hasServerConfiguration() && server.getServerConfiguration() == null) {
			try {
				IFile file = null;
				if (ServerCore.getServerPreferences().isCreateResourcesInWorkspace())
					file = ServerUtil.getUnusedServerConfigurationFile(WizardUtil.getServerProject(), type.getServerConfigurationType());
				
				IServerConfigurationWorkingCopy serverConfiguration = type.getServerConfigurationType().importFromRuntime(null, file, runtime, new NullProgressMonitor());
				ServerUtil.setServerConfigurationDefaultName(serverConfiguration);
				model.putObject(TaskModel.TASK_SERVER_CONFIGURATION, serverConfiguration);
				server.setServerConfiguration(serverConfiguration);
				updateChildFragments();
			} catch (Exception e) {
				Trace.trace(Trace.SEVERE, "Could not create configuration", e);
			}
		}*/
	}

	/*protected void createChildFragments(List list) {
		IServerWorkingCopy server = (IServerWorkingCopy) getTaskModel().getObject(TaskModel.TASK_SERVER);
		IServerConfiguration serverConfiguration = null;
		if (server != null)
			serverConfiguration = server.getServerConfiguration();
		if (serverConfiguration != null) {
			WizardFragment sub = ServerUICore.getWizardFragment(serverConfiguration.getServerConfigurationType().getId());
			if (sub != null)
				list.add(sub);
		}
	}*/
}