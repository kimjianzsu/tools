/*******************************************************************************
 * Copyright (c) 2002 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *     Jens Lukowski/Innoopract - initial renaming/restructuring
 *     
 *******************************************************************************/
package org.eclipse.wst.xml.core.internal.contentmodel.basic;

import org.eclipse.wst.xml.core.internal.contentmodel.CMEntityDeclaration;

public class CMEntityDeclarationImpl extends CMNodeImpl implements CMEntityDeclaration
{
  protected String name;                         
  protected String value;

  public CMEntityDeclarationImpl(String name, String value)
  {
    this.name = name;
    this.value = value;
  }

  public int getNodeType()
  {
    return ENTITY_DECLARATION;
  }

  public String getNodeName()
  {
    return name;
  }
 
  public String getName()
  {
    return name;
  }

  public String getValue()
  {
    return value;
  }
}   
