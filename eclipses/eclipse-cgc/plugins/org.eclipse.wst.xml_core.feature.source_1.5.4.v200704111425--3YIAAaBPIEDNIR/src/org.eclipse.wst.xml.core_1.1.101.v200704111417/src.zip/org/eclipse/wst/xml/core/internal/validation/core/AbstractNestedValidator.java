/*******************************************************************************
 * Copyright (c) 2006 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

package org.eclipse.wst.xml.core.internal.validation.core;

import java.io.InputStream;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.ISchedulingRule;
import org.eclipse.wst.validation.internal.core.Message;
import org.eclipse.wst.validation.internal.core.ValidationException;
import org.eclipse.wst.validation.internal.provisional.core.IMessage;
import org.eclipse.wst.validation.internal.provisional.core.IReporter;
import org.eclipse.wst.validation.internal.provisional.core.IValidationContext;
import org.eclipse.wst.validation.internal.provisional.core.IValidator;
import org.eclipse.wst.validation.internal.provisional.core.IValidatorJob;

/**
 * An abstract validator that assists validators in running and contributing
 * nested messages in the validation results. 
 * *note: Subclasses do not need to contribute nested messages in order to
 * benefit from the use of this class. This class takes care of iterating
 * through results for validators that use the standard context.
 */
public abstract class AbstractNestedValidator implements IValidatorJob 
{
  // Locally used, non-UI strings.
  private static final String REFERENCED_FILE_ERROR_OPEN = "referencedFileError("; //$NON-NLS-1$
  private static final String REFERENCED_FILE_ERROR_CLOSE = ")"; //$NON-NLS-1$
  private static final String REFERENCED_FILE_ERROR = "referencedFileError"; //$NON-NLS-1$
  private static final String FILE_PROTOCOL_NO_SLASH = "file:"; //$NON-NLS-1$
  private static final String FILE_PROTOCOL = "file:///"; //$NON-NLS-1$
  private static final String GROUP_NAME = "groupName"; //$NON-NLS-1$
  private final String GET_FILE = "getFile"; //$NON-NLS-1$
  private final String GET_PROJECT_FILES = "getAllFiles"; //$NON-NLS-1$
  private final String GET_INPUTSTREAM = "inputStream"; //$NON-NLS-1$
  
  // Internal strings. These strings are common addition information types.
  protected static final String COLUMN_NUMBER_ATTRIBUTE = "columnNumber"; //$NON-NLS-1$
  protected static final String SQUIGGLE_SELECTION_STRATEGY_ATTRIBUTE = "squiggleSelectionStrategy"; //$NON-NLS-1$
  protected static final String SQUIGGLE_NAME_OR_VALUE_ATTRIBUTE = "squiggleNameOrValue"; //$NON-NLS-1$

  

  /* (non-Javadoc)
   * @see org.eclipse.wst.validation.internal.provisional.core.IValidatorJob#validateInJob(org.eclipse.wst.validation.internal.provisional.core.IValidationContext, org.eclipse.wst.validation.internal.provisional.core.IReporter)
   */
  public IStatus validateInJob(IValidationContext context, IReporter reporter) throws ValidationException 
  {
	NestedValidatorContext nestedcontext = new NestedValidatorContext();
	setupValidation(nestedcontext);
	String[] fileURIs = context.getURIs();
	if (fileURIs != null && fileURIs.length > 0) 
	{
	  int numFiles = fileURIs.length;
	  for (int i = 0; i < numFiles && !reporter.isCancelled(); i++) 
	  {
	    String fileName = fileURIs[i];
	    if (fileName != null)
	    {          
	      Object []parms = {fileName};

	      IFile file = (IFile) context.loadModel(GET_FILE, parms);
	      if (file != null && shouldValidate(file)) 
	      { 
	    	// The helper may not have a file stored in it but may have an InputStream if being
	    	// called from a source other than the validation framework such as an editor.
	        if (context.loadModel(GET_INPUTSTREAM) instanceof InputStream) //$NON-NLS-1$
	        {
	          validate(file, (InputStream)context.loadModel(GET_INPUTSTREAM), reporter, nestedcontext); //do we need the fileName?  what is int ruleGroup? //$NON-NLS-1$
	        }
	        else
	        {
	    	  validate(file, null, reporter, nestedcontext);
	        }
	      }
	    }
	  }
	}
	// TODO: Is this needed? Shouldn't the framework pass the complete list? 
	// Should I know that I'm validating a project as opposed to files?
	else 
    {
      Object []parms = {getValidatorID()};
      Collection files = (Collection) context.loadModel(GET_PROJECT_FILES, parms);
      Iterator iter = files.iterator();
      while (iter.hasNext() && !reporter.isCancelled()) 
      {
        IFile file = (IFile) iter.next();
        if(shouldValidate(file))
        {
	      validate(file, null, reporter, nestedcontext);
        }
      }
    }
	
	teardownValidation(nestedcontext);
	if(reporter.isCancelled())
	  return Status.CANCEL_STATUS;
    return Status.OK_STATUS;
  }
  
  /**
   * Provides the id of this validator. The ID is used by the validation
   * framework. It usually is the fully qualified class name of the class
   * implementing the IValidator interface.
   * 
   * @return a String with the ID of this validator.
   */
  protected String getValidatorID()
  {
    return this.getClass().getName();
  }
  
  /**
   * Get the name of this validator. The name will be reported to the
   * validation framework.
   * Subclasses must implement this method.
   * 
   * @return
   * 		The name of this validator.
   */
  protected abstract String getValidatorName();

  /**
   * Perform set up before validation runs. Subclasses may implement this
   * method to perform validation specific set up.
   * 
   * @param context
   * 		The context of the current validation.
   */
  protected void setupValidation(NestedValidatorContext context)
  {
	// Default implementation does nothing.
  }
  
  /**
   * Perform tear down after validation runs. Subclasses may implement this
   * method to perform validation specific tear down.
   * 
   * @param context
   * 		The context of the current validation.
   */
  protected void teardownValidation(NestedValidatorContext context)
  {
	// Default implementation does nothing.
  }
  
  /* (non-Javadoc)
   * @see org.eclipse.wst.validation.internal.provisional.core.IValidatorJob#getSchedulingRule(org.eclipse.wst.validation.internal.provisional.core.IValidationContext)
   */
  public ISchedulingRule getSchedulingRule(IValidationContext arg0) 
  {
	// TODO review whether returning a null rule is correct. Gary had a suggestion in the bug report.
	return null;
  }

  /* (non-Javadoc)
   * @see org.eclipse.wst.validation.internal.provisional.core.IValidator#cleanup(org.eclipse.wst.validation.internal.provisional.core.IReporter)
   */
  public void cleanup(IReporter arg0) 
  {
    // No cleanup to perform. Subclasses are free to implement this method.
  }

  /* (non-Javadoc)
   * @see org.eclipse.wst.validation.internal.provisional.core.IValidator#validate(org.eclipse.wst.validation.internal.provisional.core.IValidationContext, org.eclipse.wst.validation.internal.provisional.core.IReporter)
   */
  public void validate(IValidationContext arg0, IReporter arg1) throws ValidationException 
  {  
	// This method should not be implemented by validtors implementing the validateInJob
	// method.
  }
	
	
  /**
   * Determine if a given file should be validated. 
   * 
   * @param file The file that may be validated.
   * @return True if the file should be validated, false otherwise.
   */
  private static boolean shouldValidate(IFile file) 
  {
	IResource resource = file;
	do 
	{
	  if (resource.isDerived() || resource.isTeamPrivateMember() || 
		  !resource.isAccessible() || resource.getName().charAt(0) == '.') 
	  {
		return false;
	  }
	  resource = resource.getParent();
	}while ((resource.getType() & IResource.PROJECT) == 0);
	
	return true;
  }
  
  /**
   * Validate the given file and use the reporter for the validation messages.
   * This method does not perform the validation logic but rather delegates
   * to the validate method in subclasses to validate. This method is responsible
   * for reporting the messages that result from validation.
   * 
   * @param file 
   * 		An IFile to validate.
   * @param inputstream 
   * 		An InputStream that represents the file. The InputStream may be null
   * 		in which case the files should be validated from the IFile.
   * @param reporter 
   * 		The reporter with which to report validation messages.
   * @param context
   * 		The context of the current validation.
   */
  private void validate(IFile file, InputStream inputstream, IReporter reporter, NestedValidatorContext context)
  {  
	Message message = new LocalizedMessage(IMessage.LOW_SEVERITY, file.getFullPath().toString());
    reporter.displaySubtask(this, message);
    
	IPath path = file.getLocation();
	String uri = createURIForFilePath(path.toString());

	clearMarkers(file, this, reporter);
	ValidationReport valreport = validate(uri, inputstream, context);
	
	createMarkers(file, valreport.getValidationMessages(), reporter);
	        
	try
	{
	  file.setSessionProperty(ValidationMessage.ERROR_MESSAGE_MAP_QUALIFIED_NAME, valreport.getNestedMessages());
	}
	catch(CoreException e)
	{
	  System.out.println("Unable to set nested messages property."); //$NON-NLS-1$
	}
  }
	
  /**
   * Validate the given file and use the reporter for the validation messages.
   * Clients must implement this method with their specific validation logic.
   * 
   * @param uri
   * 		The URI of the file to validate.
   * @param inputstream 
   * 		An InputStream that represents the file. The InputStream may be null
   * 		in which case the files should be validated from the IFile.
   * @param context
   * 		The context of the current validation.
   * @return
   * 		A validation report summarizing the validation.
   */
  public abstract ValidationReport validate(String uri, InputStream inputstream, NestedValidatorContext context);
	  
  /**
   * This method clears all the markers on the given IFile for a specified
   * validator.
   * This is a convenience method for subclasses.
   * 
   * @param iFile
   * 		The IFile from which to clear the markers.
   * @param validator
   * 		The validator for which to remove the markers.
   * @param reporter
   * 		The reporter that can remove the markers.
   */
  private void clearMarkers(IFile iFile, IValidator validator, IReporter reporter)
  {
	if (fileIsAccessible(iFile))
	{
	  reporter.removeAllMessages(validator, iFile);
	}
  }
	  
  /**
   * Test whether the given file is accessible and may be used for validation. A file is 
   * available if 
   * 1. It is not null.
   * 2. It exists. 
   * 3. The project containing the file is accessible.
   * 
   * @param file 
   * 		The file to check to ensure it is accessible.
   * @return 
   * 		True if the file is accessible, false otherwise.
   */
  private boolean fileIsAccessible(IFile file)
  {
    if (file != null && file.exists() && file.getProject().isAccessible())
	{
	  return true;
	}
	return false;
  }
	  
  /**
   * Format a file name into a correct URI. 
   * This is a convenience method for subclasses.
   * 
   * @param filename 
   * 		The file name to format.
   * @return 
   * 		
   * The formatted URI.
   */
  private String createURIForFilePath(String filename)
  {
	if(!filename.startsWith(FILE_PROTOCOL_NO_SLASH))
	{
	  while(filename.startsWith("/")) //$NON-NLS-1$
	  {
	    filename = filename.substring(1);
	  }
	  filename = FILE_PROTOCOL + filename;
	}
	return filename;
  }
	  
  /**
   * Create markers for the valiation messages generated from the validation.
   * 
   * @param iFile
   *          The resource to create the markers on.
   * @param valmessages
   *          The array of validation messages.
   */
  public void createMarkers(IFile iFile, ValidationMessage[] valmessages, IReporter reporter)
  {
    if (!fileIsAccessible(iFile))
    {
      return;
    }
    int nummessages = valmessages.length;
    for (int i = 0; i < nummessages; i++)
    {
      ValidationMessage validationMessage = valmessages[i];
      String uri = validationMessage.getUri();

      LocalizedMessage message;
      if (validationMessage.getSeverity() == ValidationMessage.SEV_LOW)
      {
        message = new LocalizedMessage(IMessage.NORMAL_SEVERITY, 
        		validationMessage.getMessage(), iFile);
      }
      else
      { 
        message = new LocalizedMessage(IMessage.HIGH_SEVERITY, validationMessage.getMessage(), iFile);
      }
      
      message.setLineNo(validationMessage.getLineNumber());
      addInfoToMessage(validationMessage, message);
      
      List nestederrors = validationMessage.getNestedMessages();
      if (nestederrors != null && !nestederrors.isEmpty())
      {
        message.setGroupName(REFERENCED_FILE_ERROR_OPEN + uri + REFERENCED_FILE_ERROR_CLOSE);
      }

      reporter.addMessage(this, message);
	      
    }
    try
    {
      IMarker[] markers = iFile.findMarkers(null, true, IResource.DEPTH_INFINITE);
      for (int i = 0; i < markers.length; i++)
      {
        IMarker marker = markers[i];
        String groupName = null;
        try
        {
          groupName = (String) marker.getAttribute(GROUP_NAME);
        }
        catch (Exception e)
        {
        }
        if (groupName != null && groupName.startsWith(REFERENCED_FILE_ERROR))
        {
          marker.setAttribute(IMarker.DONE, true);
        }
      }
    }
    catch (CoreException e)
    {
      e.printStackTrace();
    }
  }
	  
  /**
   * This method allows the addition of information to the validation message
   * @param validationmessage
   * 		The ValidationMessage to retrieve the information from.
   * @param message
   * 		The IMessage to add the information to.
   */
  protected void addInfoToMessage (ValidationMessage validationmessage, IMessage message)
  { 
	// This method may be overidden by subclasses
  }
	  
  /**
   * A localized message is a specialized type of IMessage that allows setting
   * and using a localized message string for a message.
   */
  class LocalizedMessage extends Message 
  {
    private String _message = null;

	public LocalizedMessage(int severity, String messageText) 
	{
	  this(severity, messageText, null);
	}

	public LocalizedMessage(int severity, String messageText, IResource targetObject) 
	{
	  this(severity, messageText, (Object) targetObject);
	}

	public LocalizedMessage(int severity, String messageText, Object targetObject) 
	{
	  super(null, severity, null);
	  setLocalizedMessage(messageText);
	  setTargetObject(targetObject);
	}

	public void setLocalizedMessage(String message) 
	{
	  _message = message;
	}

	public String getLocalizedMessage() 
	{
	  return _message;
	}

	public String getText() 
	{
	  return getLocalizedMessage();
	}

	public String getText(ClassLoader cl) 
	{
	  return getLocalizedMessage();
	}

	public String getText(Locale l) 
	{
	  return getLocalizedMessage();
	}

	public String getText(Locale l, ClassLoader cl) 
	{
	  return getLocalizedMessage();
	}
  }
}
