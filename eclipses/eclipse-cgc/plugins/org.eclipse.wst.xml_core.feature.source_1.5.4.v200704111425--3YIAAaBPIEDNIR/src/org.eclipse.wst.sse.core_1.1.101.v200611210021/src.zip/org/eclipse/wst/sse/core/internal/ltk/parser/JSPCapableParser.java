/*******************************************************************************
 * Copyright (c) 2001, 2004 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *     Jens Lukowski/Innoopract - initial renaming/restructuring
 *     
 *******************************************************************************/
package org.eclipse.wst.sse.core.internal.ltk.parser;

import java.util.List;

public interface JSPCapableParser extends RegionParser, BlockTagParser {
	void addNestablePrefix(TagMarker marker);

	/**
	 * returns the TagMarkers for prefixes that are allowed to be nestable
	 * 
	 * @return
	 */
	List getNestablePrefixes();

	void removeNestablePrefix(String tagName);
}
