package org.eclipse.wst.rdb.derby.internal.ui.connection.dialogs;

public class Derby101UniversalNewConnectionProvider extends DerbyUniversalNewConnectionProvider {

    public Derby101UniversalNewConnectionProvider()
    {
        displayUpgrade = true;
    }
    
}
