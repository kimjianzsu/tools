package org.eclipse.wst.rdb.derby.internal.ui.connection.dialogs;


public class Derby101NewConnectionProvider extends DerbyNewConnectionProvider {

    public Derby101NewConnectionProvider()
    {
        displayUpgrade = true;
    }
}
