package org.eclipse.wst.rdb.derby.internal.ui.connection.dialogs;

public class Derby101ClientNewConnectionProvider extends DerbyClientNewConnectionProvider {
    
    public Derby101ClientNewConnectionProvider()
    {
        displayUpgrade = true;
    }
}
